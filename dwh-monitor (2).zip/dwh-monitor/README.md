# DWH Monitor

Spring Boot application for monitoring Data Warehouse tables (Iceberg + Hive) via Apache Trino.
All metrics are stored as **Iceberg tables in Trino** — no external database required.

## Architecture

```
00:05  DailySeedJob          seeds EXPECTED rows for every configured table
:00/:15/:30/:45  BatchCheckJob    checks if batches arrived, detects volume anomalies
:00 (hourly)  MissingDetectorJob  marks overdue EXPECTED rows as MISSING
:30 (hourly)  IcebergCheckJob     collects technical Iceberg health metrics
```

## Append-only storage model

Every state change writes a **new row** to the Iceberg table. No UPDATEs.
Current state is always derived by `ROW_NUMBER() OVER (...ORDER BY recorded_at DESC) = 1`.

```
recorded_at 00:05 → status=EXPECTED   (seeded)
recorded_at 05:47 → status=OK         (data arrived)
recorded_at 05:48 → status=OK         (volume comparison added)
```

Benefits: full audit history, Iceberg-friendly (bulk append >> single-row update),
all state queryable directly in Trino.

## Two Monitoring Types

| Type | Use case | batch_key |
|---|---|---|
| `BATCH` | Fact tables with a `batch_name` column | value from batch_name column |
| `TABLE` | Dim tables monitored as a whole | table_name (convention) |

## Quick Start

### 1. Configure application.yml

```yaml
trino:
  host: your-trino-host
  port: 443
  ssl: true
  user: your-user
  password: your-password
  catalog: hive          # default catalog for monitored tables
  schema: default
  metrics:
    catalog: hive        # where to store monitoring metrics
    schema: monitoring   # schema will be created automatically
```

Or via environment variables:
```bash
export TRINO_HOST=your-trino-host
export TRINO_USER=your-user
export TRINO_PASSWORD=your-password
export TRINO_METRICS_CATALOG=hive
export TRINO_METRICS_SCHEMA=monitoring
```

### 2. Start the application

```bash
./gradlew bootRun
```

On first startup, SchemaInitializer creates:
- `hive.monitoring.monitoring_config`
- `hive.monitoring.batch_runs`
- `hive.monitoring.iceberg_table_metrics`

### 3. Add tables to monitoring_config

```sql
-- Fact table with batch_name column
INSERT INTO hive.monitoring.monitoring_config VALUES (
    'fact_orders', 'hive', 'sales', 'BATCH',
    'batch_name', 'order_date', NULL,
    6, NULL,                      -- expected by 06:00, dynamic batch key discovery
    30.0, 60.0, 0.001, 0.05,
    'data-team', 'data@company.com', TRUE, NOW()
);

-- Dim table (whole table)
INSERT INTO hive.monitoring.monitoring_config VALUES (
    'dim_customers', 'hive', 'sales', 'TABLE',
    NULL, NULL, 'updated_at',
    4, NULL,
    20.0, 50.0, 0.001, 0.05,
    'data-team', 'data@company.com', TRUE, NOW()
);
```

### 4. Seed today and trigger first check

```bash
curl -X POST http://localhost:8080/api/monitoring/trigger/seed
curl -X POST http://localhost:8080/api/monitoring/trigger/check
```

## REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/monitoring/issues/today` | All MISSING/LATE/ANOMALY today |
| GET | `/api/monitoring/batch?date=2025-01-15` | Current state for a date |
| GET | `/api/monitoring/batch/{tableName}?schema=sales&days=30` | Table history |
| GET | `/api/monitoring/iceberg/health` | Iceberg technical health |
| POST | `/api/monitoring/trigger/seed?date=2025-01-15` | Manually seed a date |
| POST | `/api/monitoring/trigger/check` | Manually run batch check |
| POST | `/api/monitoring/trigger/iceberg` | Manually run Iceberg checks |

## Metrics Tables

| Table | Description |
|-------|-------------|
| `monitoring_config` | What to monitor — type, thresholds, SLA, owner |
| `batch_runs` | Append-only log — every check writes a row, partitioned by day(recorded_at) |
| `iceberg_table_metrics` | Technical health snapshots, partitioned by day(recorded_at) |

## Iceberg Checks

| Check | Warning threshold |
|-------|-------------------|
| Freshness | > 25h since last snapshot |
| Small files | > 30% of files < 10 MB |
| Snapshot accumulation | > 50 snapshots |
| Delete file ratio | > 20% delete files |
| Schema change | Any column added/removed/renamed |

## Retention

Old data can be cleaned up by deleting old partitions directly in Trino:
```sql
DELETE FROM hive.monitoring.batch_runs
WHERE recorded_at < CURRENT_TIMESTAMP - INTERVAL '90' DAY;

ALTER TABLE hive.monitoring.batch_runs EXECUTE expire_snapshots(retention_threshold => '7d');
ALTER TABLE hive.monitoring.batch_runs EXECUTE optimize;
```

## Build

```bash
./gradlew bootJar          # produces build/libs/dwh-monitor.jar
./gradlew bootRun          # run locally
```
