rootProject.name = "dwh-monitor"
