-- =================================================================
-- DWH Monitor — Dashboard SQL Queries
-- Run directly against Trino, pointing at the metrics catalog/schema
-- Replace hive.monitoring with your actual metrics catalog.schema
-- =================================================================

-- Helper: current state CTE — reuse across queries
-- (Trino doesn't support CTEs in views, so copy-paste as needed)


-- -----------------------------------------------------------------
-- 1. TODAY'S STATUS OVERVIEW
--    Shows the latest status for every (table, batch_key) today
-- -----------------------------------------------------------------
SELECT
    table_name,
    batch_key,
    status,
    expected_by,
    arrived_at,
    delay_minutes,
    row_count,
    ROUND(row_count_pct_change, 1) AS volume_change_pct,
    is_volume_anomaly
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE business_date = CURRENT_DATE
)
WHERE rn = 1
ORDER BY
    CASE status
        WHEN 'MISSING'  THEN 1
        WHEN 'ANOMALY'  THEN 2
        WHEN 'LATE'     THEN 3
        WHEN 'EXPECTED' THEN 4
        WHEN 'OK'       THEN 5
    END,
    table_name, batch_key;


-- -----------------------------------------------------------------
-- 2. PROBLEMS TODAY (MISSING / LATE / ANOMALY)
-- -----------------------------------------------------------------
SELECT
    table_name,
    batch_key,
    status,
    expected_by,
    COALESCE(CAST(delay_minutes AS VARCHAR) || ' min', 'not arrived') AS delay,
    anomaly_details
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE business_date = CURRENT_DATE
)
WHERE rn = 1
  AND status IN ('MISSING', 'LATE', 'ANOMALY')
ORDER BY status, table_name;


-- -----------------------------------------------------------------
-- 3. VOLUME TREND — last 30 days for one table
-- -----------------------------------------------------------------
SELECT
    business_date,
    batch_key,
    status,
    row_count,
    row_count_prev_week,
    ROUND(row_count_pct_change, 1) AS pct_change,
    is_volume_anomaly
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY business_date, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE table_name    = 'fact_orders'
      AND schema_name   = 'sales'
      AND business_date >= CURRENT_DATE - INTERVAL '30' DAY
)
WHERE rn = 1
ORDER BY business_date DESC, batch_key;


-- -----------------------------------------------------------------
-- 4. SLA COMPLIANCE — last 30 days per table
-- -----------------------------------------------------------------
SELECT
    table_name,
    COUNT(*)                                              AS total,
    COUNT(*) FILTER (WHERE status = 'OK')                AS on_time,
    COUNT(*) FILTER (WHERE status = 'LATE')              AS late,
    COUNT(*) FILTER (WHERE status = 'MISSING')           AS missing,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status = 'OK')
        / NULLIF(COUNT(*) FILTER (WHERE status != 'EXPECTED'), 0),
        1
    )                                                     AS sla_pct
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name, business_date, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE business_date >= CURRENT_DATE - INTERVAL '30' DAY
)
WHERE rn = 1
GROUP BY table_name
ORDER BY sla_pct ASC;


-- -----------------------------------------------------------------
-- 5. BATCH ARRIVAL TIME PATTERN (spot recurring delays)
-- -----------------------------------------------------------------
SELECT
    table_name,
    batch_key,
    business_date,
    arrived_at,
    delay_minutes,
    status
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name, business_date, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE business_date >= CURRENT_DATE - INTERVAL '14' DAY
      AND arrived_at IS NOT NULL
)
WHERE rn = 1
ORDER BY table_name, business_date DESC;


-- -----------------------------------------------------------------
-- 6. ICEBERG TECHNICAL HEALTH — latest per table
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    ROUND(hours_since_snapshot, 1)           AS hours_since_update,
    snapshot_count,
    total_file_count,
    small_file_count,
    ROUND(small_file_ratio * 100, 1)         AS small_files_pct,
    ROUND(delete_file_ratio * 100, 1)        AS delete_files_pct,
    ROUND(total_size_mb, 0)                  AS total_size_mb,
    is_freshness_warning,
    is_small_files_warning,
    is_snapshots_warning,
    is_schema_changed,
    recorded_at                              AS last_checked
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.iceberg_table_metrics
)
WHERE rn = 1
ORDER BY
    (is_freshness_warning OR is_small_files_warning
     OR is_snapshots_warning OR is_schema_changed) DESC,
    table_name;


-- -----------------------------------------------------------------
-- 7. TABLES NEEDING MAINTENANCE
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    snapshot_count,
    ROUND(small_file_ratio * 100, 1)   AS small_files_pct,
    ROUND(delete_file_ratio * 100, 1)  AS delete_files_pct,
    CASE
        WHEN snapshot_count > 200       THEN 'URGENT: Run EXPIRE SNAPSHOTS'
        WHEN snapshot_count > 50        THEN 'Run EXPIRE SNAPSHOTS'
        WHEN small_file_ratio  > 0.5    THEN 'Run OPTIMIZE (many small files)'
        WHEN delete_file_ratio > 0.2    THEN 'Run OPTIMIZE + VACUUM'
        ELSE 'OK'
    END AS recommendation
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.iceberg_table_metrics
)
WHERE rn = 1
  AND (is_small_files_warning = TRUE
       OR is_snapshots_warning = TRUE
       OR delete_file_ratio > 0.2)
ORDER BY snapshot_count DESC;


-- -----------------------------------------------------------------
-- 8. SCHEMA CHANGES HISTORY
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    schema_hash,
    column_count,
    recorded_at AS detected_at
FROM hive.monitoring.iceberg_table_metrics
WHERE is_schema_changed = TRUE
ORDER BY recorded_at DESC
LIMIT 50;


-- -----------------------------------------------------------------
-- 9. WEEKLY SUMMARY
-- -----------------------------------------------------------------
SELECT
    date_trunc('week', business_date)                     AS week,
    COUNT(DISTINCT table_name)                            AS tables_monitored,
    COUNT(*)                                              AS total_batches,
    COUNT(*) FILTER (WHERE status = 'OK')                AS ok,
    COUNT(*) FILTER (WHERE status = 'LATE')              AS late,
    COUNT(*) FILTER (WHERE status = 'MISSING')           AS missing,
    COUNT(*) FILTER (WHERE is_volume_anomaly = TRUE)     AS volume_anomalies,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status = 'OK')
        / NULLIF(COUNT(*) FILTER (WHERE status != 'EXPECTED'), 0),
        1
    )                                                     AS sla_pct
FROM (
    SELECT *,
           ROW_NUMBER() OVER (
               PARTITION BY table_name, schema_name, business_date, batch_key
               ORDER BY recorded_at DESC
           ) AS rn
    FROM hive.monitoring.batch_runs
    WHERE business_date >= CURRENT_DATE - INTERVAL '8' WEEK
)
WHERE rn = 1
GROUP BY date_trunc('week', business_date)
ORDER BY week DESC;


-- -----------------------------------------------------------------
-- 10. RETENTION CLEANUP — delete old partitions (run periodically)
--     Trino/Iceberg: drop partitions older than 90 days
-- -----------------------------------------------------------------
-- DELETE FROM hive.monitoring.batch_runs
-- WHERE recorded_at < CURRENT_TIMESTAMP - INTERVAL '90' DAY;
--
-- DELETE FROM hive.monitoring.iceberg_table_metrics
-- WHERE recorded_at < CURRENT_TIMESTAMP - INTERVAL '90' DAY;
--
-- Then run maintenance:
-- ALTER TABLE hive.monitoring.batch_runs EXECUTE expire_snapshots(retention_threshold => '7d');
-- ALTER TABLE hive.monitoring.batch_runs EXECUTE optimize;
