package com.monitoring.scheduler;

import com.monitoring.service.BatchMonitorService;
import com.monitoring.service.DailySeedService;
import com.monitoring.service.IcebergMonitorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * All scheduled jobs live here.
 *
 * Job 1: DailySeedJob         — 00:05 every day
 * Job 2: BatchMonitorJob      — every 15 minutes
 * Job 3: MissingDetectorJob   — every hour
 * Job 4: IcebergTechnicalJob  — every hour (offset by 30 min)
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MonitoringScheduler {

    private final DailySeedService dailySeedService;
    private final BatchMonitorService batchMonitorService;
    private final IcebergMonitorService icebergMonitorService;

    /**
     * Job 1: Seed EXPECTED records for today.
     * Runs at 00:05 every day (5 min after midnight to avoid DST edge cases).
     */
    @Scheduled(cron = "${monitoring.seed-cron:0 5 0 * * *}")
    public void dailySeedJob() {
        LocalDate today = LocalDate.now();
        log.info("=== DailySeedJob started for {} ===", today);
        try {
            dailySeedService.seedForDate(today);
            log.info("=== DailySeedJob completed for {} ===", today);
        } catch (Exception e) {
            log.error("DailySeedJob failed for {}: {}", today, e.getMessage(), e);
        }
    }

    /**
     * Job 2: Check if batches have arrived.
     * Runs every 15 minutes.
     */
    @Scheduled(cron = "${monitoring.check-cron:0 */15 * * * *}")
    public void batchCheckJob() {
        LocalDate today = LocalDate.now();
        log.debug("=== BatchCheckJob started at {} ===", LocalDateTime.now());
        try {
            batchMonitorService.checkAllTables(today);
        } catch (Exception e) {
            log.error("BatchCheckJob failed: {}", e.getMessage(), e);
        }
    }

    /**
     * Job 3: Mark overdue batches as MISSING.
     * Runs every hour at :00.
     */
    @Scheduled(cron = "${monitoring.missing-cron:0 0 * * * *}")
    public void missingDetectorJob() {
        log.debug("=== MissingDetectorJob started ===");
        try {
            int count = batchMonitorService.markMissingBatches();
            if (count > 0) {
                log.warn("MissingDetectorJob: marked {} batches as MISSING", count);
            }
        } catch (Exception e) {
            log.error("MissingDetectorJob failed: {}", e.getMessage(), e);
        }
    }

    /**
     * Job 4: Iceberg technical health checks.
     * Runs every hour at :30 (offset from missing detector).
     */
    @Scheduled(cron = "${monitoring.iceberg-cron:0 30 * * * *}")
    public void icebergCheckJob() {
        log.info("=== IcebergCheckJob started ===");
        try {
            icebergMonitorService.checkAllTables();
            log.info("=== IcebergCheckJob completed ===");
        } catch (Exception e) {
            log.error("IcebergCheckJob failed: {}", e.getMessage(), e);
        }
    }
}
