package com.monitoring.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "trino")
public class TrinoProperties {
    private String host;
    private int port = 443;
    private boolean ssl = true;
    private String user;
    private String password;
    private String catalog;
    private String schema;
    private int connectionTimeoutSeconds = 30;
    private int queryTimeoutSeconds = 300;

    /** Catalog and schema where monitoring metric tables live */
    private Metrics metrics = new Metrics();

    @Data
    public static class Metrics {
        private String catalog = "hive";
        private String schema  = "monitoring";
    }
}
