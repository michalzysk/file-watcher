package com.monitoring.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Creates the monitoring schema and Iceberg tables on application startup.
 * Replaces Flyway migrations — Trino DDL is idempotent via IF NOT EXISTS.
 *
 * All metric tables use:
 * - FORMAT = PARQUET
 * - Partitioning by day(recorded_at) for efficient queries and cleanup
 * - Append-only pattern (no UPDATE/DELETE on metric rows)
 */
@Slf4j
public class SchemaInitializer implements ApplicationRunner {

    private final JdbcTemplate jdbc;
    private final String metricsCatalog;
    private final String metricsSchema;

    public SchemaInitializer(JdbcTemplate jdbc, TrinoProperties props) {
        this.jdbc           = jdbc;
        this.metricsCatalog = props.getMetrics().getCatalog();
        this.metricsSchema  = props.getMetrics().getSchema();
    }

    @Override
    public void run(ApplicationArguments args) {
        log.info("Initializing monitoring schema: {}.{}", metricsCatalog, metricsSchema);
        try {
            createSchema();
            createMonitoringConfigTable();
            createBatchRunsTable();
            createIcebergTableMetricsTable();
            log.info("Monitoring schema initialized successfully");
        } catch (Exception e) {
            log.error("Failed to initialize monitoring schema: {}", e.getMessage(), e);
            throw new RuntimeException("Cannot start without monitoring schema", e);
        }
    }

    private void createSchema() {
        jdbc.execute("CREATE SCHEMA IF NOT EXISTS " + metricsCatalog + "." + metricsSchema);
        log.debug("Schema {}.{} ready", metricsCatalog, metricsSchema);
    }

    private void createMonitoringConfigTable() {
        // monitoring_config is small and rarely updated — store as Iceberg but
        // treat as a config table (updated manually via INSERT + latest-row pattern)
        jdbc.execute("""
                CREATE TABLE IF NOT EXISTS %s.%s.monitoring_config (
                    table_name              VARCHAR,
                    catalog_name            VARCHAR,
                    schema_name             VARCHAR,

                    -- BATCH: fact tables with a batch_name column
                    -- TABLE: dim tables monitored as a whole unit
                    monitoring_type         VARCHAR,

                    -- BATCH type: column containing batch identifier
                    batch_key_column        VARCHAR,
                    -- BATCH type: column containing the business date
                    business_date_column    VARCHAR,
                    -- TABLE type: column used for freshness check (e.g. updated_at)
                    freshness_column        VARCHAR,

                    -- Hour of day (UTC) by which batch should arrive
                    expected_arrival_hour   INT,
                    -- Optional JSON array of known batch keys e.g. '["EU","US"]'
                    -- NULL means discover keys dynamically from the table
                    expected_batch_keys     VARCHAR,

                    -- Volume anomaly thresholds (pct change vs same weekday last week)
                    volume_warn_pct         DOUBLE,
                    volume_crit_pct         DOUBLE,

                    max_duplicate_rate      DOUBLE,
                    max_null_rate           DOUBLE,

                    owner_team              VARCHAR,
                    owner_email             VARCHAR,
                    is_enabled              BOOLEAN,

                    -- Append-only: use latest recorded_at per (table_name, schema_name)
                    recorded_at             TIMESTAMP(6)
                )
                WITH (
                    format = 'PARQUET',
                    partitioning = ARRAY['month(recorded_at)']
                )
                """.formatted(metricsCatalog, metricsSchema));
        log.debug("Table monitoring_config ready");
    }

    private void createBatchRunsTable() {
        jdbc.execute("""
                CREATE TABLE IF NOT EXISTS %s.%s.batch_runs (
                    table_name              VARCHAR,
                    schema_name             VARCHAR,
                    catalog_name            VARCHAR,
                    business_date           DATE,

                    -- For BATCH tables: value from batch_name column
                    -- For TABLE (dim): same as table_name (convention)
                    batch_key               VARCHAR,

                    -- EXPECTED  : seeded at start of day, data not yet arrived
                    -- OK        : arrived on time
                    -- LATE      : arrived after expected_by
                    -- MISSING   : expected_by passed, still no data
                    -- ANOMALY   : volume change exceeds threshold
                    status                  VARCHAR,

                    expected_by             TIMESTAMP(6),
                    arrived_at              TIMESTAMP(6),
                    delay_minutes           INT,

                    row_count               BIGINT,
                    row_count_prev_week     BIGINT,
                    row_count_pct_change    DOUBLE,

                    is_volume_anomaly       BOOLEAN,
                    anomaly_details         VARCHAR,
                    check_count             INT,

                    -- Partition column — every check appends a new row
                    recorded_at             TIMESTAMP(6)
                )
                WITH (
                    format = 'PARQUET',
                    partitioning = ARRAY['day(recorded_at)']
                )
                """.formatted(metricsCatalog, metricsSchema));
        log.debug("Table batch_runs ready");
    }

    private void createIcebergTableMetricsTable() {
        jdbc.execute("""
                CREATE TABLE IF NOT EXISTS %s.%s.iceberg_table_metrics (
                    table_name              VARCHAR,
                    schema_name             VARCHAR,
                    catalog_name            VARCHAR,

                    -- Freshness
                    last_snapshot_at        TIMESTAMP(6),
                    hours_since_snapshot    DOUBLE,

                    -- File health
                    total_file_count        BIGINT,
                    small_file_count        BIGINT,
                    small_file_ratio        DOUBLE,
                    total_size_mb           DOUBLE,
                    avg_file_size_mb        DOUBLE,

                    -- Snapshot accumulation
                    snapshot_count          INT,
                    oldest_snapshot_at      TIMESTAMP(6),

                    -- Delete files (tables with row-level deletes/updates)
                    data_file_count         BIGINT,
                    delete_file_count       BIGINT,
                    delete_file_ratio       DOUBLE,

                    -- Schema
                    column_count            INT,
                    schema_hash             VARCHAR,

                    -- Warning flags
                    is_freshness_warning    BOOLEAN,
                    is_small_files_warning  BOOLEAN,
                    is_snapshots_warning    BOOLEAN,
                    is_schema_changed       BOOLEAN,

                    recorded_at             TIMESTAMP(6)
                )
                WITH (
                    format = 'PARQUET',
                    partitioning = ARRAY['day(recorded_at)']
                )
                """.formatted(metricsCatalog, metricsSchema));
        log.debug("Table iceberg_table_metrics ready");
    }
}
