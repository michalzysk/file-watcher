package com.monitoring.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.*;
import java.util.Properties;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class TrinoConfig {

    private final TrinoProperties props;

    /**
     * Creates a fresh Trino JDBC connection.
     * No pooling — Trino queries are analytical, pooling doesn't help here.
     */
    public Connection createTrinoConnection() throws SQLException {
        String url = buildJdbcUrl();
        Properties properties = buildConnectionProperties();
        log.debug("Connecting to Trino at {}", url);
        return DriverManager.getConnection(url, properties);
    }

    /**
     * JdbcTemplate backed by Trino — used by repositories for metrics writes/reads.
     */
    @Bean
    public JdbcTemplate jdbcTemplate() {
        return new JdbcTemplate(new TrinoDataSource(this));
    }

    /**
     * Creates the monitoring schema and Iceberg metric tables on startup
     * if they don't already exist.
     */
    @Bean
    public SchemaInitializer schemaInitializer(JdbcTemplate jdbcTemplate) {
        return new SchemaInitializer(jdbcTemplate, props);
    }

    // ----------------------------------------------------------------

    private String buildJdbcUrl() {
        return String.format("jdbc:trino://%s:%d/%s/%s",
                props.getHost(),
                props.getPort(),
                props.getCatalog(),
                props.getSchema());
    }

    private Properties buildConnectionProperties() {
        Properties p = new Properties();
        p.setProperty("user", props.getUser());
        if (props.getPassword() != null && !props.getPassword().isEmpty()) {
            p.setProperty("password", props.getPassword());
        }
        if (props.isSsl()) {
            p.setProperty("SSL", "true");
            // Uncomment for custom certs:
            // p.setProperty("SSLTrustStorePath", "/path/to/truststore.jks");
            // p.setProperty("SSLTrustStorePassword", "changeit");
        }
        p.setProperty("queryTimeout", String.valueOf(props.getQueryTimeoutSeconds()));
        return p;
    }

    // ----------------------------------------------------------------
    // Minimal DataSource wrapper — no pooling
    // ----------------------------------------------------------------

    public static class TrinoDataSource implements DataSource {
        private final TrinoConfig config;

        public TrinoDataSource(TrinoConfig config) {
            this.config = config;
        }

        @Override public Connection getConnection() throws SQLException {
            return config.createTrinoConnection();
        }

        @Override public Connection getConnection(String u, String p) throws SQLException {
            return config.createTrinoConnection();
        }

        @Override public <T> T unwrap(Class<T> i) throws SQLException { throw new SQLException("Not a wrapper"); }
        @Override public boolean isWrapperFor(Class<?> i) { return false; }
        @Override public java.io.PrintWriter getLogWriter() { return null; }
        @Override public void setLogWriter(java.io.PrintWriter o) {}
        @Override public void setLoginTimeout(int s) {}
        @Override public int getLoginTimeout() { return 0; }
        @Override public java.util.logging.Logger getParentLogger() { return null; }
    }
}
