package com.monitoring.repository;

import com.monitoring.config.TrinoProperties;
import com.monitoring.model.MonitoringConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class MonitoringConfigRepository {

    private final JdbcTemplate jdbcTemplate;
    private final TrinoProperties props;

    private String table() {
        return props.getMetrics().getCatalog() + "." + props.getMetrics().getSchema() + ".monitoring_config";
    }

    private final RowMapper<MonitoringConfig> rowMapper = (rs, rowNum) -> {
        MonitoringConfig c = new MonitoringConfig();
        c.setTableName(rs.getString("table_name"));
        c.setCatalogName(rs.getString("catalog_name"));
        c.setSchemaName(rs.getString("schema_name"));
        c.setMonitoringType(MonitoringConfig.MonitoringType.valueOf(rs.getString("monitoring_type")));
        c.setBatchKeyColumn(rs.getString("batch_key_column"));
        c.setBusinessDateColumn(rs.getString("business_date_column"));
        c.setFreshnessColumn(rs.getString("freshness_column"));
        c.setExpectedArrivalHour(rs.getInt("expected_arrival_hour"));
        c.setExpectedBatchKeys(rs.getString("expected_batch_keys"));
        c.setVolumeWarnPct(rs.getBigDecimal("volume_warn_pct"));
        c.setVolumeCritPct(rs.getBigDecimal("volume_crit_pct"));
        c.setMaxDuplicateRate(rs.getBigDecimal("max_duplicate_rate"));
        c.setMaxNullRate(rs.getBigDecimal("max_null_rate"));
        c.setOwnerTeam(rs.getString("owner_team"));
        c.setOwnerEmail(rs.getString("owner_email"));
        c.setEnabled(rs.getBoolean("is_enabled"));
        return c;
    };

    /**
     * Returns the latest config per (table_name, schema_name) — append-only pattern.
     */
    public List<MonitoringConfig> findAllEnabled() {
        String sql = """
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY table_name, schema_name
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                )
                WHERE rn = 1
                  AND is_enabled = TRUE
                ORDER BY table_name
                """.formatted(table());
        return jdbcTemplate.query(sql, rowMapper);
    }

    /**
     * Upsert config: appends a new row. Latest row wins via ROW_NUMBER() in reads.
     */
    public void save(MonitoringConfig c) {
        jdbcTemplate.update("""
                INSERT INTO %s
                    (table_name, catalog_name, schema_name, monitoring_type,
                     batch_key_column, business_date_column, freshness_column,
                     expected_arrival_hour, expected_batch_keys,
                     volume_warn_pct, volume_crit_pct, max_duplicate_rate, max_null_rate,
                     owner_team, owner_email, is_enabled, recorded_at)
                VALUES (?,?,?,?, ?,?,?, ?,?, ?,?,?,?, ?,?,?, NOW())
                """.formatted(table()),
                c.getTableName(), c.getCatalogName(), c.getSchemaName(),
                c.getMonitoringType().name(),
                c.getBatchKeyColumn(), c.getBusinessDateColumn(), c.getFreshnessColumn(),
                c.getExpectedArrivalHour(), c.getExpectedBatchKeys(),
                c.getVolumeWarnPct(), c.getVolumeCritPct(),
                c.getMaxDuplicateRate(), c.getMaxNullRate(),
                c.getOwnerTeam(), c.getOwnerEmail(), c.isEnabled()
        );
    }
}
