package com.monitoring.repository;

import com.monitoring.config.TrinoProperties;
import com.monitoring.model.BatchRun;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Append-only repository for batch_runs Iceberg table.
 *
 * Every state change = new INSERT row.
 * Current state is always the latest row per (table_name, batch_key, business_date).
 *
 * Typical lifecycle for one batch:
 *   recorded_at 00:05 → status=EXPECTED  (seeded)
 *   recorded_at 05:47 → status=OK        (data arrived)
 *   recorded_at 06:30 → status=OK        (volume comparison added)
 */
@Repository
@RequiredArgsConstructor
public class BatchRunRepository {

    private final JdbcTemplate jdbcTemplate;
    private final TrinoProperties props;

    private String table() {
        return props.getMetrics().getCatalog() + "." + props.getMetrics().getSchema() + ".batch_runs";
    }

    private final RowMapper<BatchRun> rowMapper = (rs, rowNum) -> {
        Timestamp arrivedAt = rs.getTimestamp("arrived_at");
        return BatchRun.builder()
                .tableName(rs.getString("table_name"))
                .schemaName(rs.getString("schema_name"))
                .catalogName(rs.getString("catalog_name"))
                .businessDate(rs.getDate("business_date").toLocalDate())
                .batchKey(rs.getString("batch_key"))
                .status(BatchRun.BatchStatus.valueOf(rs.getString("status")))
                .expectedBy(rs.getTimestamp("expected_by").toLocalDateTime())
                .arrivedAt(arrivedAt != null ? arrivedAt.toLocalDateTime() : null)
                .delayMinutes(rs.getObject("delay_minutes", Integer.class))
                .rowCount(rs.getObject("row_count", Long.class))
                .rowCountPrevWeek(rs.getObject("row_count_prev_week", Long.class))
                .rowCountPctChange(rs.getBigDecimal("row_count_pct_change"))
                .volumeAnomaly(rs.getBoolean("is_volume_anomaly"))
                .anomalyDetails(rs.getString("anomaly_details"))
                .checkCount(rs.getInt("check_count"))
                .recordedAt(rs.getTimestamp("recorded_at").toLocalDateTime())
                .build();
    };

    // ----------------------------------------------------------------
    // Writes — all append-only INSERTs
    // ----------------------------------------------------------------

    /**
     * Seed an EXPECTED record at start of day.
     * Idempotent: if an EXPECTED row for this key already exists today, skip.
     */
    public void seedExpected(BatchRun run) {
        if (existsForToday(run.getTableName(), run.getSchemaName(),
                run.getBusinessDate(), run.getBatchKey())) {
            return;
        }
        insertRow(run.getTableName(), run.getSchemaName(), run.getCatalogName(),
                run.getBusinessDate(), run.getBatchKey(),
                BatchRun.BatchStatus.EXPECTED, run.getExpectedBy(),
                null, null, null, null, null, false, null, 0);
    }

    /**
     * Append a new row reflecting that data has arrived.
     * Carries forward previous check_count + 1.
     */
    public void appendArrived(String tableName, String schemaName, String catalogName,
                               LocalDate businessDate, String batchKey,
                               LocalDateTime expectedBy, LocalDateTime arrivedAt,
                               long rowCount, int prevCheckCount) {
        BatchRun.BatchStatus status = arrivedAt.isAfter(expectedBy)
                ? BatchRun.BatchStatus.LATE : BatchRun.BatchStatus.OK;
        int delayMinutes = (int) java.time.Duration.between(expectedBy, arrivedAt).toMinutes();

        insertRow(tableName, schemaName, catalogName, businessDate, batchKey,
                status, expectedBy, arrivedAt, delayMinutes,
                rowCount, null, null, false, null, prevCheckCount + 1);
    }

    /**
     * Append a row with updated volume comparison data.
     * Carries the rest of the state from the latest row.
     */
    public void appendVolumeComparison(BatchRun latest,
                                        long prevWeekCount, double pctChange,
                                        boolean isAnomaly, String anomalyDetails) {
        BatchRun.BatchStatus status = isAnomaly
                ? BatchRun.BatchStatus.ANOMALY : latest.getStatus();

        insertRow(latest.getTableName(), latest.getSchemaName(), latest.getCatalogName(),
                latest.getBusinessDate(), latest.getBatchKey(),
                status, latest.getExpectedBy(), latest.getArrivedAt(),
                latest.getDelayMinutes(), latest.getRowCount(),
                prevWeekCount, pctChange, isAnomaly, anomalyDetails,
                latest.getCheckCount() + 1);
    }

    /**
     * Append a MISSING row for all records that are past expected_by with no data.
     * Returns count of rows marked missing.
     */
    public int appendMissingForOverdue() {
        List<BatchRun> overdue = findExpectedOverdue();
        for (BatchRun run : overdue) {
            insertRow(run.getTableName(), run.getSchemaName(), run.getCatalogName(),
                    run.getBusinessDate(), run.getBatchKey(),
                    BatchRun.BatchStatus.MISSING, run.getExpectedBy(),
                    null, null, null, null, null, false,
                    "No data arrived by expected_by", run.getCheckCount() + 1);
        }
        return overdue.size();
    }

    /**
     * Append a check-count-only heartbeat for still-EXPECTED records.
     */
    public void appendHeartbeat(BatchRun run) {
        insertRow(run.getTableName(), run.getSchemaName(), run.getCatalogName(),
                run.getBusinessDate(), run.getBatchKey(),
                BatchRun.BatchStatus.EXPECTED, run.getExpectedBy(),
                null, null, null, null, null, false, null,
                run.getCheckCount() + 1);
    }

    // ----------------------------------------------------------------
    // Reads — always latest row per (table, batch_key, business_date)
    // ----------------------------------------------------------------

    /**
     * Current state for all (table, batch_key) on a given business_date.
     */
    public List<BatchRun> findCurrentStateForDate(LocalDate date) {
        return jdbcTemplate.query("""
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY table_name, schema_name, batch_key
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                    WHERE business_date = DATE '%s'
                )
                WHERE rn = 1
                ORDER BY table_name, batch_key
                """.formatted(table(), date), rowMapper);
    }

    /**
     * Current state filtered by status.
     */
    public List<BatchRun> findCurrentStateByStatus(LocalDate date, BatchRun.BatchStatus status) {
        return jdbcTemplate.query("""
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY table_name, schema_name, batch_key
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                    WHERE business_date = DATE '%s'
                )
                WHERE rn = 1
                  AND status = '%s'
                ORDER BY table_name, batch_key
                """.formatted(table(), date, status.name()), rowMapper);
    }

    /**
     * All EXPECTED records for today whose expected_by has passed (candidates for MISSING).
     */
    public List<BatchRun> findExpectedOverdue() {
        return jdbcTemplate.query("""
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY table_name, schema_name, batch_key
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                    WHERE business_date = CURRENT_DATE
                )
                WHERE rn = 1
                  AND status = 'EXPECTED'
                  AND expected_by < NOW()
                  AND arrived_at IS NULL
                """.formatted(table()), rowMapper);
    }

    /**
     * Current state of EXPECTED records for today (still waiting for data).
     */
    public List<BatchRun> findExpectedForToday() {
        return findCurrentStateByStatus(LocalDate.now(), BatchRun.BatchStatus.EXPECTED);
    }

    /**
     * Recent history for a table — all rows for last N days, latest state per day.
     */
    public List<BatchRun> findRecentByTable(String tableName, String schemaName, int days) {
        return jdbcTemplate.query("""
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY business_date, batch_key
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                    WHERE table_name  = '%s'
                      AND schema_name = '%s'
                      AND business_date >= CURRENT_DATE - INTERVAL '%d' DAY
                )
                WHERE rn = 1
                ORDER BY business_date DESC, batch_key
                """.formatted(table(), tableName, schemaName, days), rowMapper);
    }

    /**
     * Row count from same weekday N weeks ago — for volume comparison baseline.
     */
    public Long findRowCountSameWeekday(String tableName, String schemaName,
                                         String batchKey, LocalDate businessDate, int weeksAgo) {
        LocalDate targetDate = businessDate.minusWeeks(weeksAgo);
        List<Long> result = jdbcTemplate.query("""
                SELECT row_count
                FROM (
                    SELECT row_count, status,
                           ROW_NUMBER() OVER (ORDER BY recorded_at DESC) AS rn
                    FROM %s
                    WHERE table_name    = '%s'
                      AND schema_name   = '%s'
                      AND batch_key     = '%s'
                      AND business_date = DATE '%s'
                )
                WHERE rn = 1
                  AND status IN ('OK', 'LATE', 'ANOMALY')
                  AND row_count IS NOT NULL
                LIMIT 1
                """.formatted(table(), tableName, schemaName, batchKey, targetDate),
                (rs, i) -> rs.getLong("row_count"));
        return result.isEmpty() ? null : result.get(0);
    }

    /**
     * Check whether any row (any status) exists for this key today — used by seedExpected.
     */
    public boolean existsForToday(String tableName, String schemaName,
                                   LocalDate businessDate, String batchKey) {
        List<Long> result = jdbcTemplate.query("""
                SELECT COUNT(*) AS cnt
                FROM %s
                WHERE table_name    = '%s'
                  AND schema_name   = '%s'
                  AND business_date = DATE '%s'
                  AND batch_key     = '%s'
                LIMIT 1
                """.formatted(table(), tableName, schemaName, businessDate, batchKey),
                (rs, i) -> rs.getLong("cnt"));
        return !result.isEmpty() && result.get(0) > 0;
    }

    // ----------------------------------------------------------------
    // Private helpers
    // ----------------------------------------------------------------

    private void insertRow(String tableName, String schemaName, String catalogName,
                            LocalDate businessDate, String batchKey,
                            BatchRun.BatchStatus status, LocalDateTime expectedBy,
                            LocalDateTime arrivedAt, Integer delayMinutes,
                            Long rowCount, Long rowCountPrevWeek, Double rowCountPctChange,
                            boolean isVolumeAnomaly, String anomalyDetails, int checkCount) {
        jdbcTemplate.update("""
                INSERT INTO %s
                    (table_name, schema_name, catalog_name, business_date, batch_key,
                     status, expected_by, arrived_at, delay_minutes,
                     row_count, row_count_prev_week, row_count_pct_change,
                     is_volume_anomaly, anomaly_details, check_count, recorded_at)
                VALUES (?,?,?,?,?, ?,?,?,?, ?,?,?, ?,?,?, NOW())
                """.formatted(table()),
                tableName, schemaName, catalogName, businessDate, batchKey,
                status.name(),
                Timestamp.valueOf(expectedBy),
                arrivedAt != null ? Timestamp.valueOf(arrivedAt) : null,
                delayMinutes,
                rowCount, rowCountPrevWeek, rowCountPctChange,
                isVolumeAnomaly, anomalyDetails, checkCount
        );
    }
}
