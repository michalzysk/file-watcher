package com.monitoring.repository;

import com.monitoring.config.TrinoProperties;
import com.monitoring.model.IcebergTableMetrics;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class IcebergMetricsRepository {

    private final JdbcTemplate jdbcTemplate;
    private final TrinoProperties props;

    private String table() {
        return props.getMetrics().getCatalog() + "." + props.getMetrics().getSchema() + ".iceberg_table_metrics";
    }

    public void save(IcebergTableMetrics m) {
        jdbcTemplate.update("""
                INSERT INTO %s
                    (table_name, schema_name, catalog_name,
                     last_snapshot_at, hours_since_snapshot,
                     total_file_count, small_file_count, small_file_ratio,
                     total_size_mb, avg_file_size_mb,
                     snapshot_count, oldest_snapshot_at,
                     data_file_count, delete_file_count, delete_file_ratio,
                     column_count, schema_hash,
                     is_freshness_warning, is_small_files_warning,
                     is_snapshots_warning, is_schema_changed,
                     recorded_at)
                VALUES (?,?,?, ?,?, ?,?,?, ?,?, ?,?, ?,?,?, ?,?, ?,?,?,?, NOW())
                """.formatted(table()),
                m.getTableName(), m.getSchemaName(), m.getCatalogName(),
                m.getLastSnapshotAt() != null ? Timestamp.valueOf(m.getLastSnapshotAt()) : null,
                m.getHoursSinceSnapshot() != null ? m.getHoursSinceSnapshot().doubleValue() : null,
                m.getTotalFileCount(), m.getSmallFileCount(),
                m.getSmallFileRatio() != null ? m.getSmallFileRatio().doubleValue() : null,
                m.getTotalSizeMb() != null ? m.getTotalSizeMb().doubleValue() : null,
                m.getAvgFileSizeMb() != null ? m.getAvgFileSizeMb().doubleValue() : null,
                m.getSnapshotCount(),
                m.getOldestSnapshotAt() != null ? Timestamp.valueOf(m.getOldestSnapshotAt()) : null,
                m.getDataFileCount(), m.getDeleteFileCount(),
                m.getDeleteFileRatio() != null ? m.getDeleteFileRatio().doubleValue() : null,
                m.getColumnCount(), m.getSchemaHash(),
                m.isFreshnessWarning(), m.isSmallFilesWarning(),
                m.isSnapshotsWarning(), m.isSchemaChanged()
        );
    }

    /**
     * Last schema hash for a table — used to detect schema changes.
     */
    public Optional<String> findLastSchemaHash(String tableName, String schemaName) {
        List<String> result = jdbcTemplate.query("""
                SELECT schema_hash
                FROM %s
                WHERE table_name  = '%s'
                  AND schema_name = '%s'
                ORDER BY recorded_at DESC
                LIMIT 1
                """.formatted(table(), tableName, schemaName),
                (rs, i) -> rs.getString("schema_hash"));
        return result.isEmpty() ? Optional.empty() : Optional.ofNullable(result.get(0));
    }

    /**
     * Latest metrics per table — used by health dashboard endpoint.
     */
    public List<IcebergTableMetrics> findLatestPerTable() {
        return jdbcTemplate.query("""
                SELECT *
                FROM (
                    SELECT *,
                           ROW_NUMBER() OVER (
                               PARTITION BY table_name, schema_name
                               ORDER BY recorded_at DESC
                           ) AS rn
                    FROM %s
                )
                WHERE rn = 1
                ORDER BY table_name
                """.formatted(table()),
                (rs, rowNum) -> IcebergTableMetrics.builder()
                        .tableName(rs.getString("table_name"))
                        .schemaName(rs.getString("schema_name"))
                        .catalogName(rs.getString("catalog_name"))
                        .snapshotCount(rs.getInt("snapshot_count"))
                        .smallFileRatio(rs.getBigDecimal("small_file_ratio"))
                        .deleteFileRatio(rs.getBigDecimal("delete_file_ratio"))
                        .hoursSinceSnapshot(rs.getBigDecimal("hours_since_snapshot"))
                        .freshnessWarning(rs.getBoolean("is_freshness_warning"))
                        .smallFilesWarning(rs.getBoolean("is_small_files_warning"))
                        .snapshotsWarning(rs.getBoolean("is_snapshots_warning"))
                        .schemaChanged(rs.getBoolean("is_schema_changed"))
                        .checkedAt(rs.getTimestamp("recorded_at").toLocalDateTime())
                        .build()
        );
    }
}
