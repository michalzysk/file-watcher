package com.monitoring.service;

import com.monitoring.model.BatchRun;
import com.monitoring.model.BatchRun.BatchStatus;
import com.monitoring.model.MonitoringConfig;
import com.monitoring.repository.BatchRunRepository;
import com.monitoring.repository.MonitoringConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Checks if batches have arrived and evaluates volume anomalies.
 * Every state transition = new appended row in batch_runs.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BatchMonitorService {

    private final MonitoringConfigRepository configRepository;
    private final BatchRunRepository batchRunRepository;
    private final TrinoQueryService trinoQueryService;

    public void checkAllTables(LocalDate businessDate) {
        List<MonitoringConfig> configs = configRepository.findAllEnabled();
        log.info("Running batch checks for {} tables, business_date={}", configs.size(), businessDate);

        for (MonitoringConfig config : configs) {
            try {
                if (config.getMonitoringType() == MonitoringConfig.MonitoringType.TABLE) {
                    checkDimTable(config, businessDate);
                } else {
                    checkFactTable(config, businessDate);
                }
            } catch (Exception e) {
                log.error("Error checking {}: {}", config.getFullTableName(), e.getMessage(), e);
            }
        }
    }

    // ----------------------------------------------------------------
    // DIM table — whole table as one unit
    // ----------------------------------------------------------------

    private void checkDimTable(MonitoringConfig config, LocalDate businessDate) {
        String batchKey = config.getTableName();
        LocalDateTime expectedBy = businessDate.atTime(config.getExpectedArrivalHour(), 0);

        // Get current state
        List<BatchRun> currentState = batchRunRepository.findCurrentStateForDate(businessDate);
        Optional<BatchRun> existing = currentState.stream()
                .filter(r -> r.getTableName().equals(config.getTableName())
                        && r.getBatchKey().equals(batchKey))
                .findFirst();

        // If already OK/LATE/ANOMALY — nothing to do
        if (existing.isPresent() && existing.get().getStatus() != BatchRun.BatchStatus.EXPECTED) {
            return;
        }

        int prevCheckCount = existing.map(BatchRun::getCheckCount).orElse(0);

        // Check freshness via last modified column
        Optional<LocalDateTime> lastModified = trinoQueryService.getTableLastModified(config);
        Map<String, Long> counts = trinoQueryService.getTableRowCount(config);

        if (!counts.isEmpty()) {
            long rowCount = counts.values().iterator().next();
            LocalDateTime arrivedAt = lastModified.orElse(LocalDateTime.now());

            batchRunRepository.appendArrived(config.getTableName(), config.getSchemaName(),
                    config.getCatalogName(), businessDate, batchKey,
                    expectedBy, arrivedAt, rowCount, prevCheckCount);

            log.info("DIM {} arrived: {} rows", config.getTableName(), rowCount);
            evaluateVolumeAnomaly(config, businessDate, batchKey, rowCount,
                    prevCheckCount + 1, expectedBy, arrivedAt);
        } else {
            // Still waiting — append heartbeat with incremented check_count
            batchRunRepository.appendHeartbeat(
                    existing.orElse(BatchRun.builder()
                            .tableName(config.getTableName())
                            .schemaName(config.getSchemaName())
                            .catalogName(config.getCatalogName())
                            .businessDate(businessDate).batchKey(batchKey)
                            .status(BatchRun.BatchStatus.EXPECTED)
                            .expectedBy(expectedBy).checkCount(prevCheckCount).build())
            );
        }
    }

    // ----------------------------------------------------------------
    // FACT table — per batch_key
    // ----------------------------------------------------------------

    private void checkFactTable(MonitoringConfig config, LocalDate businessDate) {
        LocalDateTime expectedBy = businessDate.atTime(config.getExpectedArrivalHour(), 0);

        // Query Trino for actual batch keys present today
        Map<String, Long> batchKeyCounts = trinoQueryService.getBatchKeyCounts(config, businessDate);

        if (batchKeyCounts.isEmpty()) {
            log.debug("No data yet for {} on {}", config.getFullTableName(), businessDate);
            // Heartbeat for all EXPECTED records
            batchRunRepository.findExpectedForToday().stream()
                    .filter(r -> r.getTableName().equals(config.getTableName()))
                    .forEach(batchRunRepository::appendHeartbeat);
            return;
        }

        // Get current state snapshot
        List<BatchRun> currentState = batchRunRepository.findCurrentStateForDate(businessDate);

        for (Map.Entry<String, Long> entry : batchKeyCounts.entrySet()) {
            String batchKey = entry.getKey();
            long rowCount = entry.getValue();

            Optional<BatchRun> existing = currentState.stream()
                    .filter(r -> r.getTableName().equals(config.getTableName())
                            && r.getBatchKey().equals(batchKey))
                    .findFirst();

            // Already processed
            if (existing.isPresent() && existing.get().getStatus() != BatchRun.BatchStatus.EXPECTED) {
                continue;
            }

            int prevCheckCount = existing.map(BatchRun::getCheckCount).orElse(0);

            // Seed if we discovered a new batch key not in the initial seed
            if (existing.isEmpty()) {
                batchRunRepository.seedExpected(BatchRun.builder()
                        .tableName(config.getTableName()).schemaName(config.getSchemaName())
                        .catalogName(config.getCatalogName()).businessDate(businessDate)
                        .batchKey(batchKey).status(BatchRun.BatchStatus.EXPECTED)
                        .expectedBy(expectedBy).checkCount(0).build());
            }

            LocalDateTime arrivedAt = LocalDateTime.now();
            batchRunRepository.appendArrived(config.getTableName(), config.getSchemaName(),
                    config.getCatalogName(), businessDate, batchKey,
                    expectedBy, arrivedAt, rowCount, prevCheckCount);

            log.info("Batch {}/{} arrived: {} rows ({})",
                    config.getTableName(), batchKey, rowCount,
                    arrivedAt.isAfter(expectedBy) ? "LATE" : "ON TIME");

            evaluateVolumeAnomaly(config, businessDate, batchKey, rowCount,
                    prevCheckCount + 1, expectedBy, arrivedAt);
        }
    }

    // ----------------------------------------------------------------
    // Volume anomaly detection
    // ----------------------------------------------------------------

    private void evaluateVolumeAnomaly(MonitoringConfig config, LocalDate businessDate,
                                        String batchKey, long currentCount,
                                        int checkCount, LocalDateTime expectedBy,
                                        LocalDateTime arrivedAt) {
        Long prevWeekCount = null;
        for (int weeksAgo = 1; weeksAgo <= 4; weeksAgo++) {
            prevWeekCount = batchRunRepository.findRowCountSameWeekday(
                    config.getTableName(), config.getSchemaName(), batchKey, businessDate, weeksAgo);
            if (prevWeekCount != null && prevWeekCount > 0) break;
        }

        if (prevWeekCount == null || prevWeekCount == 0) {
            log.debug("No historical baseline for volume comparison: {}/{}", config.getTableName(), batchKey);
            return;
        }

        double pctChange = ((double)(currentCount - prevWeekCount) / prevWeekCount) * 100.0;
        double absPct = Math.abs(pctChange);
        boolean isAnomaly = absPct >= config.getVolumeCritPct().doubleValue();
        boolean isWarning = !isAnomaly && absPct >= config.getVolumeWarnPct().doubleValue();

        String anomalyDetails = null;
        if (isAnomaly || isWarning) {
            anomalyDetails = String.format("%s volume change: %.1f%% (current=%d, prev_week=%d)",
                    isAnomaly ? "CRITICAL" : "WARNING", pctChange, currentCount, prevWeekCount);
            log.warn("Volume anomaly for {}/{}: {}", config.getTableName(), batchKey, anomalyDetails);
        }

        // Build a synthetic "latest" run to pass into appendVolumeComparison
        BatchStatus status = arrivedAt.isAfter(expectedBy)
                ? BatchRun.BatchStatus.LATE : BatchRun.BatchStatus.OK;

        BatchRun latest = BatchRun.builder()
                .tableName(config.getTableName()).schemaName(config.getSchemaName())
                .catalogName(config.getCatalogName()).businessDate(businessDate)
                .batchKey(batchKey).status(status).expectedBy(expectedBy)
                .arrivedAt(arrivedAt)
                .delayMinutes((int) java.time.Duration.between(expectedBy, arrivedAt).toMinutes())
                .rowCount(currentCount).checkCount(checkCount).build();

        batchRunRepository.appendVolumeComparison(latest, prevWeekCount, pctChange, isAnomaly, anomalyDetails);
    }

    /**
     * Mark overdue EXPECTED records as MISSING. Called hourly.
     */
    public int markMissingBatches() {
        int count = batchRunRepository.appendMissingForOverdue();
        if (count > 0) {
            log.warn("Marked {} batch runs as MISSING", count);
        }
        return count;
    }
}
