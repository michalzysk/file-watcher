package com.monitoring.service;

import com.monitoring.config.TrinoConfig;
import com.monitoring.model.MonitoringConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

/**
 * All Trino queries live here. Each method opens its own connection
 * and closes it when done — Trino queries can be long-running.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TrinoQueryService {

    private final TrinoConfig trinoConfig;

    // ----------------------------------------------------------------
    // BATCH monitoring queries
    // ----------------------------------------------------------------

    /**
     * For BATCH tables: get distinct batch keys that exist for a given business date.
     * Returns map of batchKey -> rowCount.
     */
    public Map<String, Long> getBatchKeyCounts(MonitoringConfig config, LocalDate businessDate) {
        String sql = """
                SELECT %s as batch_key, COUNT(*) as row_count
                FROM %s
                WHERE CAST(%s AS DATE) = DATE '%s'
                GROUP BY %s
                """.formatted(
                config.getBatchKeyColumn(),
                config.getFullTableName(),
                config.getBusinessDateColumn(),
                businessDate,
                config.getBatchKeyColumn()
        );

        return executeMapQuery(sql, config.getFullTableName());
    }

    /**
     * For TABLE (dim) tables: get total row count and earliest arrived_at equivalent.
     * Returns map with single key = table_name -> rowCount.
     */
    public Map<String, Long> getTableRowCount(MonitoringConfig config) {
        String sql = "SELECT COUNT(*) as row_count FROM " + config.getFullTableName();

        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                long count = rs.getLong("row_count");
                log.debug("Table {} row count: {}", config.getFullTableName(), count);
                return Map.of(config.getTableName(), count);
            }
        } catch (SQLException e) {
            log.error("Error getting row count for {}: {}", config.getFullTableName(), e.getMessage());
        }
        return Collections.emptyMap();
    }

    /**
     * For TABLE (dim) tables: when was the table last modified?
     */
    public Optional<LocalDateTime> getTableLastModified(MonitoringConfig config) {
        if (config.getFreshnessColumn() == null) {
            return Optional.empty();
        }

        String sql = "SELECT MAX(%s) as last_modified FROM %s"
                .formatted(config.getFreshnessColumn(), config.getFullTableName());

        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                Timestamp ts = rs.getTimestamp("last_modified");
                return ts != null ? Optional.of(ts.toLocalDateTime()) : Optional.empty();
            }
        } catch (SQLException e) {
            log.error("Error getting last modified for {}: {}", config.getFullTableName(), e.getMessage());
        }
        return Optional.empty();
    }

    // ----------------------------------------------------------------
    // Iceberg metadata queries
    // ----------------------------------------------------------------

    /**
     * Query Iceberg $snapshots table for last snapshot time.
     */
    public Optional<LocalDateTime> getLastSnapshotTime(String catalog, String schema, String table) {
        String fullName = catalog + ".\"" + schema + "\".\"" + table + "$snapshots\"";
        String sql = "SELECT MAX(committed_at) as last_snapshot FROM " + fullName;

        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                Timestamp ts = rs.getTimestamp("last_snapshot");
                return ts != null ? Optional.of(ts.toLocalDateTime()) : Optional.empty();
            }
        } catch (SQLException e) {
            log.warn("Cannot query snapshots for {}.{}.{} (may be Hive table): {}",
                    catalog, schema, table, e.getMessage());
        }
        return Optional.empty();
    }

    /**
     * Query Iceberg $snapshots for count and oldest.
     */
    public Map<String, Object> getSnapshotStats(String catalog, String schema, String table) {
        String fullName = catalog + ".\"" + schema + "\".\"" + table + "$snapshots\"";
        String sql = """
                SELECT COUNT(*) as snapshot_count,
                       MIN(committed_at) as oldest_snapshot
                FROM %s
                """.formatted(fullName);

        Map<String, Object> result = new HashMap<>();
        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                result.put("snapshot_count", rs.getInt("snapshot_count"));
                Timestamp oldest = rs.getTimestamp("oldest_snapshot");
                if (oldest != null) result.put("oldest_snapshot", oldest.toLocalDateTime());
            }
        } catch (SQLException e) {
            log.warn("Cannot query snapshot stats for {}.{}.{}: {}", catalog, schema, table, e.getMessage());
        }
        return result;
    }

    /**
     * Query Iceberg $files for file size distribution.
     */
    public Map<String, Object> getFileStats(String catalog, String schema, String table) {
        String fullName = catalog + ".\"" + schema + "\".\"" + table + "$files\"";
        String sql = """
                SELECT
                    COUNT(*)                                                         AS total_files,
                    SUM(file_size_in_bytes) / 1024.0 / 1024.0                       AS total_size_mb,
                    AVG(file_size_in_bytes) / 1024.0 / 1024.0                       AS avg_size_mb,
                    COUNT(CASE WHEN file_size_in_bytes < 10 * 1024 * 1024 THEN 1 END) AS small_files,
                    COUNT(CASE WHEN content = 0 THEN 1 END)                          AS data_files,
                    COUNT(CASE WHEN content IN (1, 2) THEN 1 END)                    AS delete_files
                FROM %s
                """.formatted(fullName);

        Map<String, Object> result = new HashMap<>();
        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                result.put("total_files",  rs.getLong("total_files"));
                result.put("total_size_mb", rs.getBigDecimal("total_size_mb"));
                result.put("avg_size_mb",   rs.getBigDecimal("avg_size_mb"));
                result.put("small_files",   rs.getLong("small_files"));
                result.put("data_files",    rs.getLong("data_files"));
                result.put("delete_files",  rs.getLong("delete_files"));
            }
        } catch (SQLException e) {
            log.warn("Cannot query file stats for {}.{}.{}: {}", catalog, schema, table, e.getMessage());
        }
        return result;
    }

    /**
     * Get schema definition for a table (column names + types) for change detection.
     */
    public List<String> getTableColumns(String catalog, String schema, String table) {
        String sql = """
                SELECT column_name, data_type
                FROM %s.information_schema.columns
                WHERE table_schema = '%s' AND table_name = '%s'
                ORDER BY ordinal_position
                """.formatted(catalog, schema, table);

        List<String> columns = new ArrayList<>();
        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                columns.add(rs.getString("column_name") + ":" + rs.getString("data_type"));
            }
        } catch (SQLException e) {
            log.error("Error getting columns for {}.{}.{}: {}", catalog, schema, table, e.getMessage());
        }
        return columns;
    }

    // ----------------------------------------------------------------
    // Helpers
    // ----------------------------------------------------------------

    private Map<String, Long> executeMapQuery(String sql, String tableDescription) {
        Map<String, Long> result = new HashMap<>();
        try (Connection conn = trinoConfig.createTrinoConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String key = rs.getString("batch_key");
                long count = rs.getLong("row_count");
                result.put(key, count);
            }
            log.debug("Table {} found {} batch keys", tableDescription, result.size());
        } catch (SQLException e) {
            log.error("Error querying {}: {}", tableDescription, e.getMessage());
        }
        return result;
    }
}
