package com.monitoring.service;

import com.monitoring.model.IcebergTableMetrics;
import com.monitoring.model.MonitoringConfig;
import com.monitoring.repository.IcebergMetricsRepository;
import com.monitoring.repository.MonitoringConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.security.MessageDigest;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Collects technical health metrics for Iceberg tables.
 * Runs every hour via scheduler.
 *
 * Checks:
 * - Freshness (hours since last snapshot)
 * - File health (small files ratio, total size)
 * - Snapshot accumulation
 * - Delete file ratio
 * - Schema change detection
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class IcebergMonitorService {

    // Thresholds
    private static final double SMALL_FILE_SIZE_MB     = 10.0;
    private static final double SMALL_FILE_WARN_RATIO  = 0.30;
    private static final int    SNAPSHOT_WARN_COUNT    = 50;
    private static final int    SNAPSHOT_CRIT_COUNT    = 200;
    private static final double DELETE_FILE_WARN_RATIO = 0.20;
    private static final int    FRESHNESS_WARN_HOURS   = 25;

    private final MonitoringConfigRepository configRepository;
    private final IcebergMetricsRepository metricsRepository;
    private final TrinoQueryService trinoQueryService;

    public void checkAllTables() {
        List<MonitoringConfig> configs = configRepository.findAllEnabled();
        log.info("Running Iceberg technical checks for {} tables", configs.size());

        for (MonitoringConfig config : configs) {
            try {
                checkTable(config);
            } catch (Exception e) {
                log.error("Error checking Iceberg metrics for {}: {}",
                        config.getFullTableName(), e.getMessage(), e);
            }
        }
    }

    private void checkTable(MonitoringConfig config) {
        log.debug("Checking Iceberg metrics for {}", config.getFullTableName());
        IcebergTableMetrics.IcebergTableMetricsBuilder builder = IcebergTableMetrics.builder()
                .tableName(config.getTableName())
                .schemaName(config.getSchemaName())
                .catalogName(config.getCatalogName());

        // 1. Freshness from snapshots
        Optional<LocalDateTime> lastSnapshot = trinoQueryService.getLastSnapshotTime(
                config.getCatalogName(), config.getSchemaName(), config.getTableName());

        if (lastSnapshot.isPresent()) {
            LocalDateTime snapshotTime = lastSnapshot.get();
            double hoursSince = Duration.between(snapshotTime, LocalDateTime.now()).toMinutes() / 60.0;
            builder.lastSnapshotAt(snapshotTime)
                    .hoursSinceSnapshot(BigDecimal.valueOf(hoursSince).setScale(2, RoundingMode.HALF_UP))
                    .freshnessWarning(hoursSince > FRESHNESS_WARN_HOURS);
        }

        // 2. Snapshot stats (count, oldest)
        Map<String, Object> snapshotStats = trinoQueryService.getSnapshotStats(
                config.getCatalogName(), config.getSchemaName(), config.getTableName());

        if (!snapshotStats.isEmpty()) {
            Integer snapshotCount = (Integer) snapshotStats.get("snapshot_count");
            LocalDateTime oldestSnapshot = (LocalDateTime) snapshotStats.get("oldest_snapshot");

            builder.snapshotCount(snapshotCount)
                    .oldestSnapshotAt(oldestSnapshot)
                    .snapshotsWarning(snapshotCount != null && snapshotCount > SNAPSHOT_WARN_COUNT);

            if (snapshotCount != null && snapshotCount > SNAPSHOT_CRIT_COUNT) {
                log.warn("Table {} has {} snapshots — run EXPIRE SNAPSHOTS!", 
                        config.getFullTableName(), snapshotCount);
            }
        }

        // 3. File stats
        Map<String, Object> fileStats = trinoQueryService.getFileStats(
                config.getCatalogName(), config.getSchemaName(), config.getTableName());

        if (!fileStats.isEmpty()) {
            Long totalFiles   = (Long) fileStats.get("total_files");
            Long smallFiles   = (Long) fileStats.get("small_files");
            Long dataFiles    = (Long) fileStats.get("data_files");
            Long deleteFiles  = (Long) fileStats.get("delete_files");
            BigDecimal totalSizeMb = (BigDecimal) fileStats.get("total_size_mb");
            BigDecimal avgSizeMb   = (BigDecimal) fileStats.get("avg_size_mb");

            double smallFileRatio  = (totalFiles != null && totalFiles > 0)
                    ? (double) smallFiles / totalFiles : 0.0;
            double deleteFileRatio = (totalFiles != null && totalFiles > 0)
                    ? (double) deleteFiles / totalFiles : 0.0;

            builder.totalFileCount(totalFiles)
                    .smallFileCount(smallFiles)
                    .smallFileRatio(BigDecimal.valueOf(smallFileRatio).setScale(4, RoundingMode.HALF_UP))
                    .totalSizeMb(totalSizeMb)
                    .avgFileSizeMb(avgSizeMb)
                    .dataFileCount(dataFiles)
                    .deleteFileCount(deleteFiles)
                    .deleteFileRatio(BigDecimal.valueOf(deleteFileRatio).setScale(4, RoundingMode.HALF_UP))
                    .smallFilesWarning(smallFileRatio > SMALL_FILE_WARN_RATIO);

            if (deleteFileRatio > DELETE_FILE_WARN_RATIO) {
                log.warn("Table {} has {:.1f}% delete files — consider running OPTIMIZE + VACUUM",
                        config.getFullTableName(), deleteFileRatio * 100);
            }

            if (smallFileRatio > SMALL_FILE_WARN_RATIO) {
                log.warn("Table {} has {:.1f}% small files (<10MB) — consider running OPTIMIZE",
                        config.getFullTableName(), smallFileRatio * 100);
            }
        }

        // 4. Schema change detection
        List<String> columns = trinoQueryService.getTableColumns(
                config.getCatalogName(), config.getSchemaName(), config.getTableName());

        if (!columns.isEmpty()) {
            String schemaHash = computeHash(String.join(",", columns));
            Optional<String> lastHash = metricsRepository.findLastSchemaHash(
                    config.getTableName(), config.getSchemaName());

            boolean schemaChanged = lastHash.isPresent() && !lastHash.get().equals(schemaHash);
            if (schemaChanged) {
                log.warn("Schema change detected for {}! Previous hash: {}, New hash: {}",
                        config.getFullTableName(), lastHash.get(), schemaHash);
            }

            builder.columnCount(columns.size())
                    .schemaHash(schemaHash)
                    .schemaChanged(schemaChanged);
        }

        IcebergTableMetrics metrics = builder.build();
        metricsRepository.save(metrics);
        log.debug("Saved Iceberg metrics for {}", config.getFullTableName());
    }

    private String computeHash(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes());
            StringBuilder hex = new StringBuilder();
            for (byte b : hash) hex.append(String.format("%02x", b));
            return hex.substring(0, 16); // first 16 chars is enough
        } catch (Exception e) {
            return String.valueOf(input.hashCode());
        }
    }
}
