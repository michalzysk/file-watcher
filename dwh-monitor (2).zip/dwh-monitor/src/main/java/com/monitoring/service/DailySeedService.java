package com.monitoring.service;

import com.monitoring.model.BatchRun;
import com.monitoring.model.MonitoringConfig;
import com.monitoring.repository.BatchRunRepository;
import com.monitoring.repository.MonitoringConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Seeds EXPECTED records at the start of each day.
 *
 * For BATCH tables (fact):
 *   - Static expected_batch_keys in config → one record per key
 *   - No config → one placeholder record; real keys discovered by BatchMonitorService
 *
 * For TABLE tables (dim):
 *   - One record with batch_key = table_name
 *
 * seedExpected() is idempotent — safe to call multiple times.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DailySeedService {

    private final MonitoringConfigRepository configRepository;
    private final BatchRunRepository batchRunRepository;

    public void seedForDate(LocalDate date) {
        List<MonitoringConfig> configs = configRepository.findAllEnabled();
        log.info("Seeding EXPECTED records for {} tables on {}", configs.size(), date);

        for (MonitoringConfig config : configs) {
            try {
                if (config.getMonitoringType() == MonitoringConfig.MonitoringType.TABLE) {
                    seedDimTable(config, date);
                } else {
                    seedFactTable(config, date);
                }
            } catch (Exception e) {
                log.error("Failed to seed {}: {}", config.getTableName(), e.getMessage());
            }
        }
    }

    private void seedDimTable(MonitoringConfig config, LocalDate date) {
        batchRunRepository.seedExpected(buildExpected(config, date, config.getTableName()));
        log.debug("Seeded DIM {} for {}", config.getTableName(), date);
    }

    private void seedFactTable(MonitoringConfig config, LocalDate date) {
        if (config.getExpectedBatchKeys() != null && !config.getExpectedBatchKeys().isBlank()) {
            parseBatchKeys(config.getExpectedBatchKeys()).forEach(key -> {
                batchRunRepository.seedExpected(buildExpected(config, date, key));
            });
            log.debug("Seeded FACT {} with static batch keys for {}", config.getTableName(), date);
        } else {
            // Unknown keys — seed a placeholder; real keys discovered during checks
            batchRunRepository.seedExpected(buildExpected(config, date, "_PENDING_DISCOVERY_"));
            log.debug("Seeded FACT {} with dynamic discovery placeholder for {}", config.getTableName(), date);
        }
    }

    private BatchRun buildExpected(MonitoringConfig config, LocalDate date, String batchKey) {
        return BatchRun.builder()
                .tableName(config.getTableName())
                .schemaName(config.getSchemaName())
                .catalogName(config.getCatalogName())
                .businessDate(date)
                .batchKey(batchKey)
                .status(BatchRun.BatchStatus.EXPECTED)
                .expectedBy(date.atTime(config.getExpectedArrivalHour(), 0))
                .checkCount(0)
                .build();
    }

    private List<String> parseBatchKeys(String raw) {
        return List.of(raw.replaceAll("[\\[\\]\"]", "").split(","))
                .stream().map(String::trim).filter(s -> !s.isEmpty()).toList();
    }
}
