package com.monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class DwhMonitorApplication {
    public static void main(String[] args) {
        SpringApplication.run(DwhMonitorApplication.class, args);
    }
}
