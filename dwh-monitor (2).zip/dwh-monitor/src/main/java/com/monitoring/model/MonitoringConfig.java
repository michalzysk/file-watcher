package com.monitoring.model;

import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class MonitoringConfig {

    private Long id;
    private String tableName;
    private String catalogName;
    private String schemaName;

    /**
     * BATCH - fact tables with batch_name column
     * TABLE - dim tables, monitored as whole (batch_key = table_name)
     */
    private MonitoringType monitoringType;

    // For BATCH type
    private String batchKeyColumn;
    private String businessDateColumn;

    // For TABLE type
    private String freshnessColumn;

    private int expectedArrivalHour;
    private String expectedBatchKeys; // JSON array, null = dynamic

    private BigDecimal volumeWarnPct;
    private BigDecimal volumeCritPct;
    private BigDecimal maxDuplicateRate;
    private BigDecimal maxNullRate;

    private String ownerTeam;
    private String ownerEmail;
    private boolean enabled;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    public enum MonitoringType {
        BATCH, TABLE
    }

    public String getFullTableName() {
        return catalogName + "." + schemaName + "." + tableName;
    }
}
