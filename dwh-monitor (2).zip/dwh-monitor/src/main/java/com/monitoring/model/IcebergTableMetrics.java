package com.monitoring.model;

import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
public class IcebergTableMetrics {

    private Long id;
    private String tableName;
    private String schemaName;
    private String catalogName;

    // Freshness
    private LocalDateTime lastSnapshotAt;
    private BigDecimal hoursSinceSnapshot;

    // Files health
    private Long totalFileCount;
    private Long smallFileCount;
    private BigDecimal smallFileRatio;
    private BigDecimal totalSizeMb;
    private BigDecimal avgFileSizeMb;

    // Snapshots
    private Integer snapshotCount;
    private LocalDateTime oldestSnapshotAt;

    // Delete files
    private Long dataFileCount;
    private Long deleteFileCount;
    private BigDecimal deleteFileRatio;

    // Schema
    private Integer columnCount;
    private String schemaHash;

    // Flags
    private boolean freshnessWarning;
    private boolean smallFilesWarning;
    private boolean snapshotsWarning;
    private boolean schemaChanged;

    private LocalDateTime checkedAt;
}
