package com.monitoring.model;

import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class BatchRun {

    private String tableName;
    private String schemaName;
    private String catalogName;
    private LocalDate businessDate;
    private String batchKey;

    private BatchStatus status;

    private LocalDateTime expectedBy;
    private LocalDateTime arrivedAt;
    private Integer delayMinutes;

    private Long rowCount;
    private Long rowCountPrevWeek;
    private BigDecimal rowCountPctChange;

    private boolean volumeAnomaly;
    private String anomalyDetails;

    private int checkCount;

    /** Every row in the Iceberg table has this — the time this snapshot was written */
    private LocalDateTime recordedAt;

    public enum BatchStatus {
        EXPECTED, OK, LATE, MISSING, ANOMALY
    }
}
