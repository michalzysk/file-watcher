# DWH Monitor

Spring Boot application for monitoring Data Warehouse tables (Iceberg + Hive) via Apache Trino.

## Architecture

```
00:00  DailySeedJob      → seeds EXPECTED records for every configured table
:00/:15/:30/:45  BatchCheckJob → checks if batches arrived, detects volume anomalies  
:00 (hourly)  MissingDetectorJob → marks overdue EXPECTED records as MISSING
:30 (hourly)  IcebergCheckJob   → collects technical Iceberg health metrics
```

## Two Monitoring Types

| Type | Use case | batch_key |
|------|----------|-----------|
| `BATCH` | Fact tables with a `batch_name` column | value from batch_name column |
| `TABLE` | Dim tables monitored as whole | table_name (convention) |

## Quick Start

### 1. Configure application.yml

```yaml
trino:
  host: your-trino-host
  port: 443
  ssl: true
  user: your-user
  password: your-password
  catalog: hive
  schema: default

spring:
  datasource:
    url: jdbc:postgresql://localhost:5432/dwh_monitoring
    username: monitoring
    password: monitoring
```

Or use environment variables:
```bash
export TRINO_HOST=your-trino-host
export TRINO_USER=your-user
export TRINO_PASSWORD=your-password
export METRICS_DB_USER=monitoring
export METRICS_DB_PASSWORD=monitoring
```

### 2. Add tables to monitoring_config

```sql
-- Fact table with batch_name column
INSERT INTO monitoring.monitoring_config
    (table_name, catalog_name, schema_name, monitoring_type,
     batch_key_column, business_date_column,
     expected_arrival_hour, owner_team)
VALUES
    ('fact_orders', 'hive', 'sales', 'BATCH',
     'batch_name', 'order_date', 6, 'data-team');

-- Dim table (whole table)
INSERT INTO monitoring.monitoring_config
    (table_name, catalog_name, schema_name, monitoring_type,
     freshness_column, expected_arrival_hour, owner_team)
VALUES
    ('dim_customers', 'hive', 'sales', 'TABLE',
     'updated_at', 4, 'data-team');
```

### 3. Build and run

```bash
mvn clean package -DskipTests
java -jar target/dwh-monitor-1.0.0.jar
```

## REST API

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/monitoring/issues/today` | All problems today |
| GET | `/api/monitoring/batch?date=2025-01-15&status=MISSING` | Batches by date/status |
| GET | `/api/monitoring/batch/{tableName}?schema=sales&days=30` | Table history |
| GET | `/api/monitoring/iceberg/health` | Iceberg technical health |
| POST | `/api/monitoring/trigger/seed?date=2025-01-15` | Manually seed a date |
| POST | `/api/monitoring/trigger/check` | Manually run batch check |
| POST | `/api/monitoring/trigger/iceberg` | Manually run Iceberg checks |

## Metrics Tables

| Table | Description |
|-------|-------------|
| `monitoring.monitoring_config` | What to monitor and with what thresholds |
| `monitoring.batch_runs` | One row per (table, batch_key, business_date) — lifecycle: EXPECTED → OK/LATE/MISSING/ANOMALY |
| `monitoring.iceberg_table_metrics` | Technical Iceberg health (files, snapshots, schema) |

## Dashboard Queries

See `src/main/resources/dashboard-queries.sql` for 10 ready-to-use queries covering:
- Today's status overview
- SLA compliance
- Volume trends
- Batch arrival time patterns
- Iceberg maintenance recommendations
- Weekly summary

## Batch Status Lifecycle

```
00:00  → status=EXPECTED   (seeded from config)
  ↓
data arrives before expected_by  → status=OK
data arrives after expected_by   → status=LATE
expected_by passed, no data      → status=MISSING
volume change exceeds threshold  → status=ANOMALY
```

## Iceberg Checks Performed

| Check | Warning Threshold |
|-------|-------------------|
| Freshness | > 25 hours since last snapshot |
| Small files | > 30% of files under 10MB |
| Snapshot accumulation | > 50 snapshots |
| Delete file ratio | > 20% delete files |
| Schema change | Any column added/removed/renamed |
