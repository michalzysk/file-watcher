-- =================================================================
-- DWH Monitor - Dashboard SQL Queries
-- Run these directly against the metrics PostgreSQL database
-- =================================================================


-- -----------------------------------------------------------------
-- 1. TODAY'S STATUS OVERVIEW
--    Main dashboard view — what's the state of all batches today?
-- -----------------------------------------------------------------
SELECT
    table_name,
    batch_key,
    status,
    expected_by,
    arrived_at,
    delay_minutes,
    row_count,
    CASE
        WHEN row_count_pct_change IS NOT NULL
        THEN ROUND(row_count_pct_change, 1) || '%'
    END AS volume_change,
    is_volume_anomaly
FROM monitoring.batch_runs
WHERE business_date = CURRENT_DATE
ORDER BY
    CASE status
        WHEN 'MISSING' THEN 1
        WHEN 'ANOMALY'  THEN 2
        WHEN 'LATE'     THEN 3
        WHEN 'EXPECTED' THEN 4
        WHEN 'OK'       THEN 5
    END,
    table_name, batch_key;


-- -----------------------------------------------------------------
-- 2. MISSING & LATE BATCHES TODAY
-- -----------------------------------------------------------------
SELECT
    table_name,
    batch_key,
    status,
    expected_by,
    COALESCE(delay_minutes::TEXT || ' min late', 'not arrived') AS delay,
    owner_team,
    owner_email
FROM monitoring.batch_runs br
JOIN monitoring.monitoring_config mc USING (table_name)
WHERE br.business_date = CURRENT_DATE
  AND br.status IN ('MISSING', 'LATE', 'ANOMALY')
ORDER BY status, delay_minutes DESC NULLS LAST;


-- -----------------------------------------------------------------
-- 3. VOLUME TREND — last 30 days for a specific table/batch
--    Replace 'fact_orders' and 'ORDERS_EU' with your values
-- -----------------------------------------------------------------
SELECT
    business_date,
    batch_key,
    status,
    row_count,
    row_count_prev_week,
    ROUND(row_count_pct_change, 1) AS pct_change,
    is_volume_anomaly
FROM monitoring.batch_runs
WHERE table_name   = 'fact_orders'
  AND batch_key    = 'ORDERS_EU'        -- remove this line for all batch keys
  AND business_date >= CURRENT_DATE - INTERVAL '30 days'
ORDER BY business_date DESC;


-- -----------------------------------------------------------------
-- 4. BATCH ARRIVAL TIME TREND
--    Useful for spotting patterns in delays
-- -----------------------------------------------------------------
SELECT
    business_date,
    table_name,
    batch_key,
    EXTRACT(HOUR FROM arrived_at)   AS arrived_hour,
    EXTRACT(MINUTE FROM arrived_at) AS arrived_minute,
    delay_minutes,
    status
FROM monitoring.batch_runs
WHERE arrived_at IS NOT NULL
  AND business_date >= CURRENT_DATE - INTERVAL '14 days'
ORDER BY table_name, business_date DESC;


-- -----------------------------------------------------------------
-- 5. SLA COMPLIANCE — % of on-time batches per table (last 30 days)
-- -----------------------------------------------------------------
SELECT
    table_name,
    COUNT(*)                                                    AS total_batches,
    COUNT(*) FILTER (WHERE status = 'OK')                      AS on_time,
    COUNT(*) FILTER (WHERE status = 'LATE')                    AS late,
    COUNT(*) FILTER (WHERE status = 'MISSING')                 AS missing,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status = 'OK') / COUNT(*),
        1
    )                                                           AS sla_pct
FROM monitoring.batch_runs
WHERE business_date >= CURRENT_DATE - INTERVAL '30 days'
  AND status != 'EXPECTED'   -- exclude today's pending
GROUP BY table_name
ORDER BY sla_pct ASC;


-- -----------------------------------------------------------------
-- 6. AVERAGE DELAY PER TABLE (when late)
-- -----------------------------------------------------------------
SELECT
    table_name,
    COUNT(*) FILTER (WHERE delay_minutes > 0)       AS late_count,
    ROUND(AVG(delay_minutes) FILTER (WHERE delay_minutes > 0)) AS avg_delay_min,
    MAX(delay_minutes)                               AS max_delay_min
FROM monitoring.batch_runs
WHERE business_date >= CURRENT_DATE - INTERVAL '30 days'
GROUP BY table_name
HAVING COUNT(*) FILTER (WHERE delay_minutes > 0) > 0
ORDER BY avg_delay_min DESC;


-- -----------------------------------------------------------------
-- 7. ICEBERG TECHNICAL HEALTH — latest per table
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    ROUND(hours_since_snapshot, 1)              AS hours_since_update,
    snapshot_count,
    total_file_count,
    small_file_count,
    ROUND(small_file_ratio * 100, 1) || '%'     AS small_files_pct,
    ROUND(delete_file_ratio * 100, 1) || '%'    AS delete_files_pct,
    ROUND(total_size_mb, 0)                     AS total_size_mb,
    is_freshness_warning,
    is_small_files_warning,
    is_snapshots_warning,
    is_schema_changed,
    checked_at
FROM (
    SELECT DISTINCT ON (table_name, schema_name) *
    FROM monitoring.iceberg_table_metrics
    ORDER BY table_name, schema_name, checked_at DESC
) latest
ORDER BY
    (is_freshness_warning OR is_small_files_warning OR is_snapshots_warning OR is_schema_changed) DESC,
    table_name;


-- -----------------------------------------------------------------
-- 8. SCHEMA CHANGES HISTORY
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    schema_hash,
    column_count,
    checked_at
FROM monitoring.iceberg_table_metrics
WHERE is_schema_changed = TRUE
ORDER BY checked_at DESC
LIMIT 50;


-- -----------------------------------------------------------------
-- 9. TABLES NEEDING MAINTENANCE (small files or too many snapshots)
-- -----------------------------------------------------------------
SELECT
    table_name,
    schema_name,
    snapshot_count,
    small_file_count,
    ROUND(small_file_ratio * 100, 1) || '%' AS small_files_pct,
    delete_file_count,
    CASE
        WHEN snapshot_count > 200 THEN 'Run EXPIRE SNAPSHOTS urgently'
        WHEN snapshot_count > 50  THEN 'Run EXPIRE SNAPSHOTS soon'
        WHEN small_file_ratio > 0.5 THEN 'Run OPTIMIZE (many small files)'
        WHEN delete_file_ratio > 0.2 THEN 'Run OPTIMIZE + VACUUM'
        ELSE 'OK'
    END AS recommendation
FROM (
    SELECT DISTINCT ON (table_name, schema_name) *
    FROM monitoring.iceberg_table_metrics
    ORDER BY table_name, schema_name, checked_at DESC
) latest
WHERE is_small_files_warning = TRUE
   OR is_snapshots_warning   = TRUE
   OR delete_file_ratio > 0.2
ORDER BY snapshot_count DESC;


-- -----------------------------------------------------------------
-- 10. WEEKLY SUMMARY — business KPI view
--     Good for a weekly email report
-- -----------------------------------------------------------------
SELECT
    DATE_TRUNC('week', business_date)                           AS week,
    COUNT(DISTINCT table_name)                                  AS tables_monitored,
    COUNT(*)                                                    AS total_batches,
    COUNT(*) FILTER (WHERE status = 'OK')                      AS ok,
    COUNT(*) FILTER (WHERE status = 'LATE')                    AS late,
    COUNT(*) FILTER (WHERE status = 'MISSING')                 AS missing,
    COUNT(*) FILTER (WHERE is_volume_anomaly)                  AS volume_anomalies,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE status = 'OK') / NULLIF(COUNT(*), 0), 1
    )                                                           AS sla_pct
FROM monitoring.batch_runs
WHERE business_date >= CURRENT_DATE - INTERVAL '8 weeks'
  AND status != 'EXPECTED'
GROUP BY DATE_TRUNC('week', business_date)
ORDER BY week DESC;
