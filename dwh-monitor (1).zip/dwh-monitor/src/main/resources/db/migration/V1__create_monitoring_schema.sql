-- V1__create_monitoring_schema.sql

CREATE SCHEMA IF NOT EXISTS monitoring;

-- ============================================================
-- monitoring_config: defines what and how to monitor per table
-- ============================================================
CREATE TABLE monitoring.monitoring_config (
    id                      SERIAL PRIMARY KEY,
    table_name              VARCHAR(255)    NOT NULL,
    catalog_name            VARCHAR(100)    NOT NULL DEFAULT 'hive',
    schema_name             VARCHAR(100)    NOT NULL,

    -- BATCH: uses batch_key_column to identify batches (fact tables)
    -- TABLE: monitors the whole table as one unit (dim tables)
    monitoring_type         VARCHAR(10)     NOT NULL CHECK (monitoring_type IN ('BATCH', 'TABLE')),

    -- For BATCH type: column name containing batch identifier
    batch_key_column        VARCHAR(100),
    -- For BATCH type: column name containing the business date
    business_date_column    VARCHAR(100),
    -- For TABLE type: column to check for freshness (e.g. updated_at)
    freshness_column        VARCHAR(100),

    -- SLA: expected arrival hour (0-23, in UTC)
    expected_arrival_hour   INT             NOT NULL DEFAULT 6,
    -- Optional: expected batch keys per day (JSON array), null = dynamic detection
    expected_batch_keys     TEXT,

    -- Volume anomaly thresholds (% change vs same weekday last week)
    volume_warn_pct         DECIMAL(5,2)    NOT NULL DEFAULT 30.0,
    volume_crit_pct         DECIMAL(5,2)    NOT NULL DEFAULT 60.0,

    -- Quality thresholds
    max_duplicate_rate      DECIMAL(7,4)    NOT NULL DEFAULT 0.001,
    max_null_rate           DECIMAL(7,4)    NOT NULL DEFAULT 0.05,

    -- Ownership
    owner_team              VARCHAR(100),
    owner_email             VARCHAR(255),

    is_enabled              BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),

    UNIQUE (table_name, schema_name, catalog_name)
);

-- ============================================================
-- batch_runs: one record per (table, batch_key, business_date)
-- lifecycle: EXPECTED -> OK | LATE | MISSING | ANOMALY
-- ============================================================
CREATE TABLE monitoring.batch_runs (
    id                      BIGSERIAL PRIMARY KEY,
    table_name              VARCHAR(255)    NOT NULL,
    schema_name             VARCHAR(100)    NOT NULL,
    catalog_name            VARCHAR(100)    NOT NULL DEFAULT 'hive',
    business_date           DATE            NOT NULL,

    -- For BATCH tables: the actual batch_name value
    -- For TABLE (dim): same as table_name (convention)
    batch_key               VARCHAR(500)    NOT NULL,

    -- Lifecycle status
    status                  VARCHAR(20)     NOT NULL DEFAULT 'EXPECTED'
                                            CHECK (status IN ('EXPECTED','OK','LATE','MISSING','ANOMALY')),

    -- Timing
    expected_by             TIMESTAMP       NOT NULL,
    arrived_at              TIMESTAMP,                  -- null until data detected
    delay_minutes           INT,                        -- negative = early, positive = late

    -- Volume
    row_count               BIGINT,
    row_count_prev_week     BIGINT,
    row_count_pct_change    DECIMAL(10,4),

    -- Anomaly flags
    is_volume_anomaly       BOOLEAN         NOT NULL DEFAULT FALSE,
    anomaly_details         TEXT,                       -- human-readable description

    -- Audit
    created_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMP       NOT NULL DEFAULT NOW(),
    check_count             INT             NOT NULL DEFAULT 0,

    UNIQUE (table_name, schema_name, business_date, batch_key)
);

-- ============================================================
-- fact_table_metrics: quality metrics per (table, business_date)
-- ============================================================
CREATE TABLE monitoring.fact_table_metrics (
    id                      BIGSERIAL PRIMARY KEY,
    table_name              VARCHAR(255)    NOT NULL,
    schema_name             VARCHAR(100)    NOT NULL,
    business_date           DATE            NOT NULL,
    batch_key               VARCHAR(500),

    -- Volume
    row_count               BIGINT,
    total_amount            DECIMAL(24,4),
    avg_amount              DECIMAL(24,4),
    unique_key_count        BIGINT,

    -- Quality
    duplicate_count         BIGINT          NOT NULL DEFAULT 0,
    duplicate_rate          DECIMAL(10,6),
    null_counts             TEXT,                       -- JSON: {"column_name": count}
    negative_amount_count   BIGINT,

    -- Anomaly flags
    is_duplicate_anomaly    BOOLEAN         NOT NULL DEFAULT FALSE,
    is_null_anomaly         BOOLEAN         NOT NULL DEFAULT FALSE,

    checked_at              TIMESTAMP       NOT NULL DEFAULT NOW(),

    UNIQUE (table_name, schema_name, business_date, batch_key)
);

-- ============================================================
-- iceberg_table_metrics: technical Iceberg health per table
-- ============================================================
CREATE TABLE monitoring.iceberg_table_metrics (
    id                      BIGSERIAL PRIMARY KEY,
    table_name              VARCHAR(255)    NOT NULL,
    schema_name             VARCHAR(100)    NOT NULL,
    catalog_name            VARCHAR(100)    NOT NULL DEFAULT 'hive',

    -- Freshness
    last_snapshot_at        TIMESTAMP,
    hours_since_snapshot    DECIMAL(10,2),

    -- Files health
    total_file_count        BIGINT,
    small_file_count        BIGINT,         -- files < 10MB
    small_file_ratio        DECIMAL(7,4),
    total_size_mb           DECIMAL(20,2),
    avg_file_size_mb        DECIMAL(10,4),

    -- Snapshots health
    snapshot_count          INT,
    oldest_snapshot_at      TIMESTAMP,

    -- Delete files (for tables with updates/deletes)
    data_file_count         BIGINT,
    delete_file_count       BIGINT,
    delete_file_ratio       DECIMAL(7,4),

    -- Schema
    column_count            INT,
    schema_hash             VARCHAR(64),    -- to detect schema changes

    -- Anomaly flags
    is_freshness_warning    BOOLEAN         NOT NULL DEFAULT FALSE,
    is_small_files_warning  BOOLEAN         NOT NULL DEFAULT FALSE,
    is_snapshots_warning    BOOLEAN         NOT NULL DEFAULT FALSE,
    is_schema_changed       BOOLEAN         NOT NULL DEFAULT FALSE,

    checked_at              TIMESTAMP       NOT NULL DEFAULT NOW()
);

-- ============================================================
-- Indexes
-- ============================================================
CREATE INDEX idx_batch_runs_date        ON monitoring.batch_runs(business_date);
CREATE INDEX idx_batch_runs_status      ON monitoring.batch_runs(status);
CREATE INDEX idx_batch_runs_table_date  ON monitoring.batch_runs(table_name, business_date);
CREATE INDEX idx_fact_metrics_date      ON monitoring.fact_table_metrics(business_date);
CREATE INDEX idx_iceberg_table         ON monitoring.iceberg_table_metrics(table_name, schema_name);
CREATE INDEX idx_iceberg_checked       ON monitoring.iceberg_table_metrics(checked_at);
