-- V2__sample_config.sql
-- Example monitoring configuration - adjust to your actual tables

INSERT INTO monitoring.monitoring_config
    (table_name, catalog_name, schema_name, monitoring_type,
     batch_key_column, business_date_column, freshness_column,
     expected_arrival_hour, volume_warn_pct, volume_crit_pct,
     owner_team, owner_email)
VALUES
    -- Fact table with batch_name column
    ('fact_orders', 'hive', 'sales', 'BATCH',
     'batch_name', 'order_date', NULL,
     6, 30.0, 60.0,
     'data-team', 'data-team@company.com'),

    -- Fact table with batch_name, arrives later in the day
    ('fact_payments', 'hive', 'finance', 'BATCH',
     'batch_name', 'payment_date', NULL,
     8, 40.0, 70.0,
     'finance-team', 'finance@company.com'),

    -- Dim table - monitored as whole (batch_key = table_name)
    ('dim_customers', 'hive', 'sales', 'TABLE',
     NULL, NULL, 'updated_at',
     4, 20.0, 50.0,
     'data-team', 'data-team@company.com'),

    ('dim_products', 'hive', 'sales', 'TABLE',
     NULL, NULL, 'updated_at',
     4, 20.0, 50.0,
     'data-team', 'data-team@company.com');
