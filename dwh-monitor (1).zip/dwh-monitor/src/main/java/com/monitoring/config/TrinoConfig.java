package com.monitoring.config;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class TrinoConfig {

    private final TrinoProperties props;

    /**
     * Creates a Trino JDBC connection.
     * We don't pool Trino connections - each check opens/closes its own connection
     * because Trino queries are long-running and pooling doesn't help here.
     */
    public Connection createTrinoConnection() throws SQLException {
        String url = buildJdbcUrl();
        Properties properties = buildConnectionProperties();

        log.debug("Connecting to Trino at {}", url);
        return DriverManager.getConnection(url, properties);
    }

    private String buildJdbcUrl() {
        String protocol = props.isSsl() ? "https" : "http";
        return String.format("jdbc:trino://%s:%d/%s/%s",
                props.getHost(),
                props.getPort(),
                props.getCatalog(),
                props.getSchema());
    }

    private Properties buildConnectionProperties() {
        Properties properties = new Properties();
        properties.setProperty("user", props.getUser());

        if (props.getPassword() != null && !props.getPassword().isEmpty()) {
            properties.setProperty("password", props.getPassword());
        }

        if (props.isSsl()) {
            properties.setProperty("SSL", "true");
            // If you have custom certificates, add:
            // properties.setProperty("SSLTrustStorePath", "/path/to/truststore.jks");
            // properties.setProperty("SSLTrustStorePassword", "password");
        }

        // Query timeout
        properties.setProperty("queryTimeout", String.valueOf(props.getQueryTimeoutSeconds()));

        return properties;
    }

    /**
     * JdbcTemplate bean pointing to Trino.
     * Note: used for simple queries only. For complex monitoring queries
     * we use createTrinoConnection() directly to control timeouts per query.
     */
    @Bean(name = "trinoJdbcTemplate")
    public JdbcTemplate trinoJdbcTemplate() throws SQLException {
        // Wrap in a simple DataSource for Spring's JdbcTemplate
        return new JdbcTemplate(new TrinoDataSource(this));
    }

    /**
     * Minimal DataSource wrapper for Trino — no pooling, just delegates to DriverManager.
     */
    public static class TrinoDataSource implements DataSource {
        private final TrinoConfig config;

        public TrinoDataSource(TrinoConfig config) {
            this.config = config;
        }

        @Override
        public Connection getConnection() throws SQLException {
            return config.createTrinoConnection();
        }

        @Override
        public Connection getConnection(String username, String password) throws SQLException {
            return config.createTrinoConnection();
        }

        @Override
        public <T> T unwrap(Class<T> iface) throws SQLException {
            throw new SQLException("Not a wrapper");
        }

        @Override
        public boolean isWrapperFor(Class<?> iface) {
            return false;
        }

        @Override
        public java.io.PrintWriter getLogWriter() { return null; }

        @Override
        public void setLogWriter(java.io.PrintWriter out) {}

        @Override
        public void setLoginTimeout(int seconds) {}

        @Override
        public int getLoginTimeout() { return 0; }

        @Override
        public java.util.logging.Logger getParentLogger() { return null; }
    }
}
