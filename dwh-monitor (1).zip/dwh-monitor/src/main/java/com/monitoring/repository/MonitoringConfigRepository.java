package com.monitoring.repository;

import com.monitoring.model.MonitoringConfig;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
@RequiredArgsConstructor
public class MonitoringConfigRepository {

    // Uses the default (metrics) datasource — not Trino
    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<MonitoringConfig> rowMapper = (rs, rowNum) -> {
        MonitoringConfig config = new MonitoringConfig();
        config.setId(rs.getLong("id"));
        config.setTableName(rs.getString("table_name"));
        config.setCatalogName(rs.getString("catalog_name"));
        config.setSchemaName(rs.getString("schema_name"));
        config.setMonitoringType(MonitoringConfig.MonitoringType.valueOf(rs.getString("monitoring_type")));
        config.setBatchKeyColumn(rs.getString("batch_key_column"));
        config.setBusinessDateColumn(rs.getString("business_date_column"));
        config.setFreshnessColumn(rs.getString("freshness_column"));
        config.setExpectedArrivalHour(rs.getInt("expected_arrival_hour"));
        config.setExpectedBatchKeys(rs.getString("expected_batch_keys"));
        config.setVolumeWarnPct(rs.getBigDecimal("volume_warn_pct"));
        config.setVolumeCritPct(rs.getBigDecimal("volume_crit_pct"));
        config.setMaxDuplicateRate(rs.getBigDecimal("max_duplicate_rate"));
        config.setMaxNullRate(rs.getBigDecimal("max_null_rate"));
        config.setOwnerTeam(rs.getString("owner_team"));
        config.setOwnerEmail(rs.getString("owner_email"));
        config.setEnabled(rs.getBoolean("is_enabled"));
        return config;
    };

    public List<MonitoringConfig> findAllEnabled() {
        return jdbcTemplate.query(
                "SELECT * FROM monitoring.monitoring_config WHERE is_enabled = TRUE ORDER BY table_name",
                rowMapper
        );
    }

    public List<MonitoringConfig> findByType(MonitoringConfig.MonitoringType type) {
        return jdbcTemplate.query(
                "SELECT * FROM monitoring.monitoring_config WHERE is_enabled = TRUE AND monitoring_type = ? ORDER BY table_name",
                rowMapper,
                type.name()
        );
    }
}
