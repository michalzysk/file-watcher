package com.monitoring.repository;

import com.monitoring.model.IcebergTableMetrics;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class IcebergMetricsRepository {

    private final JdbcTemplate jdbcTemplate;

    public void save(IcebergTableMetrics m) {
        jdbcTemplate.update("""
                INSERT INTO monitoring.iceberg_table_metrics
                    (table_name, schema_name, catalog_name,
                     last_snapshot_at, hours_since_snapshot,
                     total_file_count, small_file_count, small_file_ratio,
                     total_size_mb, avg_file_size_mb,
                     snapshot_count, oldest_snapshot_at,
                     data_file_count, delete_file_count, delete_file_ratio,
                     column_count, schema_hash,
                     is_freshness_warning, is_small_files_warning,
                     is_snapshots_warning, is_schema_changed,
                     checked_at)
                VALUES (?,?,?, ?,?, ?,?,?, ?,?, ?,?, ?,?,?, ?,?, ?,?,?,?, NOW())
                """,
                m.getTableName(), m.getSchemaName(), m.getCatalogName(),
                m.getLastSnapshotAt() != null ? Timestamp.valueOf(m.getLastSnapshotAt()) : null,
                m.getHoursSinceSnapshot(),
                m.getTotalFileCount(), m.getSmallFileCount(), m.getSmallFileRatio(),
                m.getTotalSizeMb(), m.getAvgFileSizeMb(),
                m.getSnapshotCount(),
                m.getOldestSnapshotAt() != null ? Timestamp.valueOf(m.getOldestSnapshotAt()) : null,
                m.getDataFileCount(), m.getDeleteFileCount(), m.getDeleteFileRatio(),
                m.getColumnCount(), m.getSchemaHash(),
                m.isFreshnessWarning(), m.isSmallFilesWarning(),
                m.isSnapshotsWarning(), m.isSchemaChanged()
        );
    }

    /**
     * Get the last schema_hash for a table to detect schema changes.
     */
    public Optional<String> findLastSchemaHash(String tableName, String schemaName) {
        List<String> result = jdbcTemplate.query("""
                SELECT schema_hash FROM monitoring.iceberg_table_metrics
                WHERE table_name  = ?
                  AND schema_name = ?
                ORDER BY checked_at DESC
                LIMIT 1
                """,
                (rs, i) -> rs.getString("schema_hash"),
                tableName, schemaName
        );
        return result.isEmpty() ? Optional.empty() : Optional.ofNullable(result.get(0));
    }

    public List<IcebergTableMetrics> findLatestPerTable() {
        return jdbcTemplate.query("""
                SELECT DISTINCT ON (table_name, schema_name) *
                FROM monitoring.iceberg_table_metrics
                ORDER BY table_name, schema_name, checked_at DESC
                """,
                (rs, rowNum) -> IcebergTableMetrics.builder()
                        .tableName(rs.getString("table_name"))
                        .schemaName(rs.getString("schema_name"))
                        .snapshotCount(rs.getInt("snapshot_count"))
                        .smallFileRatio(rs.getBigDecimal("small_file_ratio"))
                        .deleteFileRatio(rs.getBigDecimal("delete_file_ratio"))
                        .freshnessWarning(rs.getBoolean("is_freshness_warning"))
                        .smallFilesWarning(rs.getBoolean("is_small_files_warning"))
                        .snapshotsWarning(rs.getBoolean("is_snapshots_warning"))
                        .schemaChanged(rs.getBoolean("is_schema_changed"))
                        .checkedAt(rs.getTimestamp("checked_at").toLocalDateTime())
                        .build()
        );
    }
}
