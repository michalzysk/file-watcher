package com.monitoring.repository;

import com.monitoring.model.BatchRun;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class BatchRunRepository {

    private final JdbcTemplate jdbcTemplate;

    private final RowMapper<BatchRun> rowMapper = (rs, rowNum) -> {
        Timestamp arrivedAt = rs.getTimestamp("arrived_at");
        return BatchRun.builder()
                .id(rs.getLong("id"))
                .tableName(rs.getString("table_name"))
                .schemaName(rs.getString("schema_name"))
                .catalogName(rs.getString("catalog_name"))
                .businessDate(rs.getDate("business_date").toLocalDate())
                .batchKey(rs.getString("batch_key"))
                .status(BatchRun.BatchStatus.valueOf(rs.getString("status")))
                .expectedBy(rs.getTimestamp("expected_by").toLocalDateTime())
                .arrivedAt(arrivedAt != null ? arrivedAt.toLocalDateTime() : null)
                .delayMinutes(rs.getObject("delay_minutes", Integer.class))
                .rowCount(rs.getObject("row_count", Long.class))
                .rowCountPrevWeek(rs.getObject("row_count_prev_week", Long.class))
                .rowCountPctChange(rs.getBigDecimal("row_count_pct_change"))
                .volumeAnomaly(rs.getBoolean("is_volume_anomaly"))
                .anomalyDetails(rs.getString("anomaly_details"))
                .createdAt(rs.getTimestamp("created_at").toLocalDateTime())
                .updatedAt(rs.getTimestamp("updated_at").toLocalDateTime())
                .checkCount(rs.getInt("check_count"))
                .build();
    };

    /**
     * Insert a new EXPECTED record for the day. Ignores if already exists
     * (idempotent — safe to call multiple times).
     */
    public void seedExpected(BatchRun run) {
        jdbcTemplate.update("""
                INSERT INTO monitoring.batch_runs
                    (table_name, schema_name, catalog_name, business_date, batch_key,
                     status, expected_by, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, 'EXPECTED', ?, NOW(), NOW())
                ON CONFLICT (table_name, schema_name, business_date, batch_key) DO NOTHING
                """,
                run.getTableName(),
                run.getSchemaName(),
                run.getCatalogName(),
                run.getBusinessDate(),
                run.getBatchKey(),
                Timestamp.valueOf(run.getExpectedBy())
        );
    }

    /**
     * Update a run when data has arrived.
     */
    public void markArrived(String tableName, String schemaName, LocalDate businessDate,
                             String batchKey, LocalDateTime arrivedAt, LocalDateTime expectedBy,
                             long rowCount) {
        String status = arrivedAt.isAfter(expectedBy) ? "LATE" : "OK";
        int delayMinutes = (int) java.time.Duration.between(expectedBy, arrivedAt).toMinutes();

        jdbcTemplate.update("""
                UPDATE monitoring.batch_runs
                SET status          = ?,
                    arrived_at      = ?,
                    delay_minutes   = ?,
                    row_count       = ?,
                    updated_at      = NOW(),
                    check_count     = check_count + 1
                WHERE table_name    = ?
                  AND schema_name   = ?
                  AND business_date = ?
                  AND batch_key     = ?
                  AND arrived_at    IS NULL
                """,
                status, Timestamp.valueOf(arrivedAt), delayMinutes, rowCount,
                tableName, schemaName, businessDate, batchKey
        );
    }

    /**
     * Update volume comparison fields and set ANOMALY if thresholds breached.
     */
    public void updateVolumeComparison(String tableName, String schemaName,
                                        LocalDate businessDate, String batchKey,
                                        long prevWeekCount, double pctChange,
                                        boolean isAnomaly, String anomalyDetails) {
        String status = isAnomaly ? "ANOMALY" : null; // null = keep current status

        if (isAnomaly) {
            jdbcTemplate.update("""
                    UPDATE monitoring.batch_runs
                    SET row_count_prev_week  = ?,
                        row_count_pct_change = ?,
                        is_volume_anomaly    = TRUE,
                        anomaly_details      = ?,
                        status               = 'ANOMALY',
                        updated_at           = NOW()
                    WHERE table_name    = ?
                      AND schema_name   = ?
                      AND business_date = ?
                      AND batch_key     = ?
                    """,
                    prevWeekCount, pctChange, anomalyDetails,
                    tableName, schemaName, businessDate, batchKey
            );
        } else {
            jdbcTemplate.update("""
                    UPDATE monitoring.batch_runs
                    SET row_count_prev_week  = ?,
                        row_count_pct_change = ?,
                        updated_at           = NOW()
                    WHERE table_name    = ?
                      AND schema_name   = ?
                      AND business_date = ?
                      AND batch_key     = ?
                    """,
                    prevWeekCount, pctChange,
                    tableName, schemaName, businessDate, batchKey
            );
        }
    }

    /**
     * Mark all EXPECTED records as MISSING when expected_by has passed.
     */
    public int markMissingOverdue() {
        return jdbcTemplate.update("""
                UPDATE monitoring.batch_runs
                SET status     = 'MISSING',
                    updated_at = NOW()
                WHERE status      = 'EXPECTED'
                  AND expected_by < NOW()
                  AND arrived_at  IS NULL
                """);
    }

    /**
     * Increment check_count for EXPECTED records (still waiting).
     */
    public void incrementCheckCount(String tableName, String schemaName,
                                     LocalDate businessDate, String batchKey) {
        jdbcTemplate.update("""
                UPDATE monitoring.batch_runs
                SET check_count = check_count + 1,
                    updated_at  = NOW()
                WHERE table_name    = ?
                  AND schema_name   = ?
                  AND business_date = ?
                  AND batch_key     = ?
                """,
                tableName, schemaName, businessDate, batchKey
        );
    }

    public List<BatchRun> findExpectedForToday() {
        return jdbcTemplate.query("""
                SELECT * FROM monitoring.batch_runs
                WHERE status = 'EXPECTED'
                  AND business_date = CURRENT_DATE
                ORDER BY table_name, batch_key
                """, rowMapper);
    }

    public List<BatchRun> findByDateAndStatus(LocalDate date, BatchRun.BatchStatus status) {
        return jdbcTemplate.query("""
                SELECT * FROM monitoring.batch_runs
                WHERE business_date = ? AND status = ?
                ORDER BY table_name, batch_key
                """, rowMapper, date, status.name());
    }

    public List<BatchRun> findRecentByTable(String tableName, String schemaName, int days) {
        return jdbcTemplate.query("""
                SELECT * FROM monitoring.batch_runs
                WHERE table_name  = ?
                  AND schema_name = ?
                  AND business_date >= CURRENT_DATE - INTERVAL '%d days'
                ORDER BY business_date DESC, batch_key
                """.formatted(days), rowMapper, tableName, schemaName);
    }

    /**
     * Get row count from same weekday N weeks ago (for volume comparison).
     */
    public Long findRowCountSameWeekdayWeeksAgo(String tableName, String schemaName,
                                                  String batchKey, LocalDate businessDate, int weeksAgo) {
        LocalDate targetDate = businessDate.minusWeeks(weeksAgo);
        List<Long> result = jdbcTemplate.query("""
                SELECT row_count FROM monitoring.batch_runs
                WHERE table_name    = ?
                  AND schema_name   = ?
                  AND batch_key     = ?
                  AND business_date = ?
                  AND status IN ('OK', 'LATE')
                  AND row_count IS NOT NULL
                LIMIT 1
                """,
                (rs, i) -> rs.getLong("row_count"),
                tableName, schemaName, batchKey, targetDate
        );
        return result.isEmpty() ? null : result.get(0);
    }
}
