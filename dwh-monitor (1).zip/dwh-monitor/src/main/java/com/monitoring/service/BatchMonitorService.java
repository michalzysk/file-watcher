package com.monitoring.service;

import com.monitoring.model.BatchRun;
import com.monitoring.model.MonitoringConfig;
import com.monitoring.repository.BatchRunRepository;
import com.monitoring.repository.MonitoringConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Core service that checks if batches have arrived and evaluates their quality.
 * Runs every 15 minutes via scheduler.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class BatchMonitorService {

    private final MonitoringConfigRepository configRepository;
    private final BatchRunRepository batchRunRepository;
    private final TrinoQueryService trinoQueryService;

    public void checkAllTables(LocalDate businessDate) {
        List<MonitoringConfig> configs = configRepository.findAllEnabled();
        log.info("Running batch checks for {} tables, business date: {}", configs.size(), businessDate);

        for (MonitoringConfig config : configs) {
            try {
                checkTable(config, businessDate);
            } catch (Exception e) {
                log.error("Error checking table {}: {}", config.getFullTableName(), e.getMessage(), e);
            }
        }
    }

    private void checkTable(MonitoringConfig config, LocalDate businessDate) {
        if (config.getMonitoringType() == MonitoringConfig.MonitoringType.TABLE) {
            checkDimTable(config, businessDate);
        } else {
            checkFactTable(config, businessDate);
        }
    }

    // ----------------------------------------------------------------
    // DIM table check (whole table as one unit)
    // ----------------------------------------------------------------

    private void checkDimTable(MonitoringConfig config, LocalDate businessDate) {
        String batchKey = config.getTableName();
        LocalDateTime expectedBy = businessDate.atTime(config.getExpectedArrivalHour(), 0);

        // Check if we already know it arrived
        List<BatchRun> existing = batchRunRepository.findByDateAndStatus(businessDate, BatchRun.BatchStatus.EXPECTED);
        boolean alreadyArrived = existing.stream()
                .noneMatch(r -> r.getTableName().equals(config.getTableName())
                        && r.getBatchKey().equals(batchKey));

        if (alreadyArrived) {
            batchRunRepository.incrementCheckCount(config.getTableName(), config.getSchemaName(),
                    businessDate, batchKey);
            return;
        }

        // Get last modified timestamp
        Optional<LocalDateTime> lastModified = trinoQueryService.getTableLastModified(config);
        Map<String, Long> counts = trinoQueryService.getTableRowCount(config);

        if (!counts.isEmpty()) {
            long rowCount = counts.values().iterator().next();
            LocalDateTime arrivedAt = lastModified.orElse(LocalDateTime.now());

            batchRunRepository.markArrived(config.getTableName(), config.getSchemaName(),
                    businessDate, batchKey, arrivedAt, expectedBy, rowCount);

            log.info("DIM table {} arrived: {} rows", config.getTableName(), rowCount);

            // Volume comparison
            evaluateVolumeAnomaly(config, businessDate, batchKey, rowCount);
        } else {
            batchRunRepository.incrementCheckCount(config.getTableName(), config.getSchemaName(),
                    businessDate, batchKey);
            log.debug("DIM table {} not yet updated for {}", config.getTableName(), businessDate);
        }
    }

    // ----------------------------------------------------------------
    // FACT table check (per batch key)
    // ----------------------------------------------------------------

    private void checkFactTable(MonitoringConfig config, LocalDate businessDate) {
        LocalDateTime expectedBy = businessDate.atTime(config.getExpectedArrivalHour(), 0);

        // Query Trino for actual batch keys present for this business_date
        Map<String, Long> batchKeyCounts = trinoQueryService.getBatchKeyCounts(config, businessDate);

        if (batchKeyCounts.isEmpty()) {
            log.debug("No data yet for {} on {}", config.getFullTableName(), businessDate);
            // Increment check count for all EXPECTED records
            List<BatchRun> expectedRuns = batchRunRepository.findExpectedForToday().stream()
                    .filter(r -> r.getTableName().equals(config.getTableName()))
                    .toList();
            expectedRuns.forEach(r -> batchRunRepository.incrementCheckCount(
                    r.getTableName(), r.getSchemaName(), r.getBusinessDate(), r.getBatchKey()));
            return;
        }

        log.info("FACT table {} has {} batch keys for {}",
                config.getFullTableName(), batchKeyCounts.size(), businessDate);

        for (Map.Entry<String, Long> entry : batchKeyCounts.entrySet()) {
            String batchKey = entry.getKey();
            long rowCount = entry.getValue();

            // Ensure record exists (may not if batch key was unknown at seed time)
            BatchRun seedRun = BatchRun.builder()
                    .tableName(config.getTableName())
                    .schemaName(config.getSchemaName())
                    .catalogName(config.getCatalogName())
                    .businessDate(businessDate)
                    .batchKey(batchKey)
                    .status(BatchRun.BatchStatus.EXPECTED)
                    .expectedBy(expectedBy)
                    .build();
            batchRunRepository.seedExpected(seedRun);

            // Mark as arrived
            LocalDateTime arrivedAt = LocalDateTime.now();
            batchRunRepository.markArrived(config.getTableName(), config.getSchemaName(),
                    businessDate, batchKey, arrivedAt, expectedBy, rowCount);

            log.info("Batch {}/{} arrived: {} rows, delay: {}",
                    config.getTableName(), batchKey, rowCount,
                    arrivedAt.isAfter(expectedBy) ? "LATE" : "ON TIME");

            // Volume anomaly detection
            evaluateVolumeAnomaly(config, businessDate, batchKey, rowCount);
        }
    }

    // ----------------------------------------------------------------
    // Volume anomaly detection
    // ----------------------------------------------------------------

    private void evaluateVolumeAnomaly(MonitoringConfig config, LocalDate businessDate,
                                        String batchKey, long currentCount) {
        // Compare with same weekday 1 week ago (most recent available)
        Long prevWeekCount = null;
        for (int weeksAgo = 1; weeksAgo <= 4; weeksAgo++) {
            prevWeekCount = batchRunRepository.findRowCountSameWeekdayWeeksAgo(
                    config.getTableName(), config.getSchemaName(), batchKey, businessDate, weeksAgo);
            if (prevWeekCount != null && prevWeekCount > 0) break;
        }

        if (prevWeekCount == null || prevWeekCount == 0) {
            log.debug("No historical data for volume comparison: {}/{}", config.getTableName(), batchKey);
            return;
        }

        double pctChange = ((double)(currentCount - prevWeekCount) / prevWeekCount) * 100.0;
        double absPctChange = Math.abs(pctChange);

        boolean isAnomaly = absPctChange >= config.getVolumeCritPct().doubleValue();
        boolean isWarning = !isAnomaly && absPctChange >= config.getVolumeWarnPct().doubleValue();

        String anomalyDetails = null;
        if (isAnomaly || isWarning) {
            anomalyDetails = String.format(
                    "%s volume change: %.1f%% (current: %d, prev week: %d) - %s",
                    isAnomaly ? "CRITICAL" : "WARNING",
                    pctChange, currentCount, prevWeekCount,
                    pctChange > 0 ? "significant increase" : "significant decrease"
            );
            log.warn("Volume anomaly detected for {}/{}: {}", config.getTableName(), batchKey, anomalyDetails);
        }

        batchRunRepository.updateVolumeComparison(
                config.getTableName(), config.getSchemaName(),
                businessDate, batchKey,
                prevWeekCount,
                BigDecimal.valueOf(pctChange).setScale(4, RoundingMode.HALF_UP).doubleValue(),
                isAnomaly,
                anomalyDetails
        );
    }

    /**
     * Mark all overdue EXPECTED records as MISSING.
     * Called hourly.
     */
    public int markMissingBatches() {
        int count = batchRunRepository.markMissingOverdue();
        if (count > 0) {
            log.warn("Marked {} batch runs as MISSING (past expected_by with no data)", count);
        }
        return count;
    }
}
