package com.monitoring.service;

import com.monitoring.model.BatchRun;
import com.monitoring.model.MonitoringConfig;
import com.monitoring.repository.BatchRunRepository;
import com.monitoring.repository.MonitoringConfigRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Seeds EXPECTED records at the start of each day for all monitored tables.
 *
 * For BATCH tables:
 *   - If expected_batch_keys is configured → seeds one record per key
 *   - If not configured → seeds a placeholder "UNKNOWN" key which will be
 *     replaced with real keys on the first successful check
 *
 * For TABLE (dim) tables:
 *   - Seeds one record with batch_key = table_name
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DailySeedService {

    private final MonitoringConfigRepository configRepository;
    private final BatchRunRepository batchRunRepository;

    public void seedForDate(LocalDate date) {
        List<MonitoringConfig> configs = configRepository.findAllEnabled();
        log.info("Seeding EXPECTED records for {} tables on {}", configs.size(), date);

        for (MonitoringConfig config : configs) {
            try {
                seedTable(config, date);
            } catch (Exception e) {
                log.error("Failed to seed {} for date {}: {}", config.getTableName(), date, e.getMessage());
            }
        }
    }

    private void seedTable(MonitoringConfig config, LocalDate date) {
        if (config.getMonitoringType() == MonitoringConfig.MonitoringType.TABLE) {
            seedDimTable(config, date);
        } else {
            seedFactTable(config, date);
        }
    }

    private void seedDimTable(MonitoringConfig config, LocalDate date) {
        // Dim table: single record, batch_key = table_name (our convention)
        BatchRun run = buildExpectedRun(config, date, config.getTableName());
        batchRunRepository.seedExpected(run);
        log.debug("Seeded DIM table {} for {}", config.getTableName(), date);
    }

    private void seedFactTable(MonitoringConfig config, LocalDate date) {
        if (config.getExpectedBatchKeys() != null && !config.getExpectedBatchKeys().isBlank()) {
            // Static list of expected batch keys from config
            List<String> batchKeys = parseBatchKeys(config.getExpectedBatchKeys());
            for (String batchKey : batchKeys) {
                BatchRun run = buildExpectedRun(config, date, batchKey);
                batchRunRepository.seedExpected(run);
            }
            log.debug("Seeded FACT table {} with {} expected batch keys for {}",
                    config.getTableName(), batchKeys.size(), date);
        } else {
            // Dynamic: we don't know batch keys upfront — seed a sentinel record
            // The BatchMonitorService will discover real keys and replace this
            BatchRun run = buildExpectedRun(config, date, "_PENDING_DISCOVERY_");
            batchRunRepository.seedExpected(run);
            log.debug("Seeded FACT table {} with dynamic batch key discovery for {}",
                    config.getTableName(), date);
        }
    }

    private BatchRun buildExpectedRun(MonitoringConfig config, LocalDate date, String batchKey) {
        LocalDateTime expectedBy = date.atTime(config.getExpectedArrivalHour(), 0);

        return BatchRun.builder()
                .tableName(config.getTableName())
                .schemaName(config.getSchemaName())
                .catalogName(config.getCatalogName())
                .businessDate(date)
                .batchKey(batchKey)
                .status(BatchRun.BatchStatus.EXPECTED)
                .expectedBy(expectedBy)
                .build();
    }

    /**
     * Parse JSON array string like ["KEY1", "KEY2"] or comma-separated "KEY1,KEY2"
     */
    private List<String> parseBatchKeys(String raw) {
        // Simple parsing: remove brackets and quotes, split by comma
        String cleaned = raw.replaceAll("[\\[\\]\"]", "").trim();
        return List.of(cleaned.split(","))
                .stream()
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}
