package com.monitoring.model;

import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
public class BatchRun {

    private Long id;
    private String tableName;
    private String schemaName;
    private String catalogName;
    private LocalDate businessDate;
    private String batchKey;

    private BatchStatus status;

    private LocalDateTime expectedBy;
    private LocalDateTime arrivedAt;
    private Integer delayMinutes;

    private Long rowCount;
    private Long rowCountPrevWeek;
    private BigDecimal rowCountPctChange;

    private boolean volumeAnomaly;
    private String anomalyDetails;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private int checkCount;

    public enum BatchStatus {
        EXPECTED, OK, LATE, MISSING, ANOMALY
    }
}
