package com.monitoring.api;

import com.monitoring.model.BatchRun;
import com.monitoring.model.IcebergTableMetrics;
import com.monitoring.repository.BatchRunRepository;
import com.monitoring.repository.IcebergMetricsRepository;
import com.monitoring.service.BatchMonitorService;
import com.monitoring.service.DailySeedService;
import com.monitoring.service.IcebergMonitorService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * REST API for querying monitoring data and manually triggering jobs.
 * Useful for dashboards (Metabase, Grafana, custom UI) and debugging.
 */
@Slf4j
@RestController
@RequestMapping("/api/monitoring")
@RequiredArgsConstructor
public class MonitoringController {

    private final BatchRunRepository batchRunRepository;
    private final IcebergMetricsRepository icebergMetricsRepository;
    private final DailySeedService dailySeedService;
    private final BatchMonitorService batchMonitorService;
    private final IcebergMonitorService icebergMonitorService;

    /**
     * Today's issues — all non-OK records
     * GET /api/monitoring/issues/today
     */
    @GetMapping("/issues/today")
    public Map<String, List<BatchRun>> getTodaysIssues() {
        LocalDate today = LocalDate.now();
        return Map.of(
                "missing",  batchRunRepository.findByDateAndStatus(today, BatchRun.BatchStatus.MISSING),
                "late",     batchRunRepository.findByDateAndStatus(today, BatchRun.BatchStatus.LATE),
                "anomaly",  batchRunRepository.findByDateAndStatus(today, BatchRun.BatchStatus.ANOMALY)
        );
    }

    /**
     * Batch status for a specific date
     * GET /api/monitoring/batch?date=2025-01-15&status=MISSING
     */
    @GetMapping("/batch")
    public List<BatchRun> getBatchesByDate(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
            @RequestParam(defaultValue = "EXPECTED") BatchRun.BatchStatus status) {
        return batchRunRepository.findByDateAndStatus(date, status);
    }

    /**
     * Recent history for a specific table
     * GET /api/monitoring/batch/fact_orders?schema=sales&days=30
     */
    @GetMapping("/batch/{tableName}")
    public List<BatchRun> getTableHistory(
            @PathVariable String tableName,
            @RequestParam(defaultValue = "sales") String schema,
            @RequestParam(defaultValue = "30") int days) {
        return batchRunRepository.findRecentByTable(tableName, schema, days);
    }

    /**
     * Latest Iceberg technical health per table
     * GET /api/monitoring/iceberg/health
     */
    @GetMapping("/iceberg/health")
    public List<IcebergTableMetrics> getIcebergHealth() {
        return icebergMetricsRepository.findLatestPerTable();
    }

    // ----------------------------------------------------------------
    // Manual trigger endpoints — useful for backfill or testing
    // ----------------------------------------------------------------

    /** POST /api/monitoring/trigger/seed?date=2025-01-15 */
    @PostMapping("/trigger/seed")
    public ResponseEntity<String> triggerSeed(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDate targetDate = date != null ? date : LocalDate.now();
        dailySeedService.seedForDate(targetDate);
        return ResponseEntity.ok("Seed completed for " + targetDate);
    }

    /** POST /api/monitoring/trigger/check?date=2025-01-15 */
    @PostMapping("/trigger/check")
    public ResponseEntity<String> triggerCheck(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        LocalDate targetDate = date != null ? date : LocalDate.now();
        batchMonitorService.checkAllTables(targetDate);
        return ResponseEntity.ok("Check completed for " + targetDate);
    }

    /** POST /api/monitoring/trigger/iceberg */
    @PostMapping("/trigger/iceberg")
    public ResponseEntity<String> triggerIceberg() {
        icebergMonitorService.checkAllTables();
        return ResponseEntity.ok("Iceberg check completed");
    }

    /** GET /api/monitoring/health */
    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "time", java.time.LocalDateTime.now().toString());
    }
}
